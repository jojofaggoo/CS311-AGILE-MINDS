﻿namespace Tiny_College_Course_Management_System
{
	partial class CourseTrackingSystemForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			label1 = new Label();
			whatCoursesaStudentEnrolledInButton = new Button();
			EnrollaStudentinaCourseButton = new Button();
			DisplayAllStudentsButton = new Button();
			AddAStudentButton = new Button();
			AddaCourseButton = new Button();
			DisplayAllCoursesButton = new Button();
			WhoIsInaCourseButton = new Button();
			ExitButton = new Button();
			SuspendLayout();
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.BorderStyle = BorderStyle.Fixed3D;
			label1.Font = new Font("Segoe Script", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label1.Location = new Point(34, 24);
			label1.Name = "label1";
			label1.Size = new Size(697, 56);
			label1.TabIndex = 0;
			label1.Text = "Tiny College Course Tracking System";
			// 
			// whatCoursesaStudentEnrolledInButton
			// 
			whatCoursesaStudentEnrolledInButton.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			whatCoursesaStudentEnrolledInButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
			whatCoursesaStudentEnrolledInButton.BackColor = SystemColors.ScrollBar;
			whatCoursesaStudentEnrolledInButton.Font = new Font("Segoe Fluent Icons", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
			whatCoursesaStudentEnrolledInButton.Location = new Point(142, 355);
			whatCoursesaStudentEnrolledInButton.Margin = new Padding(0);
			whatCoursesaStudentEnrolledInButton.Name = "whatCoursesaStudentEnrolledInButton";
			whatCoursesaStudentEnrolledInButton.Size = new Size(242, 86);
			whatCoursesaStudentEnrolledInButton.TabIndex = 1;
			whatCoursesaStudentEnrolledInButton.Text = "What Courses a Student Enrolled In";
			whatCoursesaStudentEnrolledInButton.UseVisualStyleBackColor = false;
			whatCoursesaStudentEnrolledInButton.Click += whatCoursesaStudentEnrolledInButton_Click;
			// 
			// EnrollaStudentinaCourseButton
			// 
			EnrollaStudentinaCourseButton.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			EnrollaStudentinaCourseButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
			EnrollaStudentinaCourseButton.BackColor = SystemColors.ScrollBar;
			EnrollaStudentinaCourseButton.Font = new Font("Segoe Fluent Icons", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
			EnrollaStudentinaCourseButton.Location = new Point(142, 267);
			EnrollaStudentinaCourseButton.Margin = new Padding(0);
			EnrollaStudentinaCourseButton.Name = "EnrollaStudentinaCourseButton";
			EnrollaStudentinaCourseButton.Size = new Size(242, 86);
			EnrollaStudentinaCourseButton.TabIndex = 2;
			EnrollaStudentinaCourseButton.Text = "Enroll a Student in a Course";
			EnrollaStudentinaCourseButton.UseVisualStyleBackColor = false;
			EnrollaStudentinaCourseButton.Click += EnrollaStudentinaCourseButton_Click;
			// 
			// DisplayAllStudentsButton
			// 
			DisplayAllStudentsButton.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			DisplayAllStudentsButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
			DisplayAllStudentsButton.BackColor = SystemColors.ScrollBar;
			DisplayAllStudentsButton.Font = new Font("Segoe Fluent Icons", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
			DisplayAllStudentsButton.Location = new Point(142, 181);
			DisplayAllStudentsButton.Margin = new Padding(0);
			DisplayAllStudentsButton.Name = "DisplayAllStudentsButton";
			DisplayAllStudentsButton.Size = new Size(242, 86);
			DisplayAllStudentsButton.TabIndex = 3;
			DisplayAllStudentsButton.Text = "Display All Students";
			DisplayAllStudentsButton.UseVisualStyleBackColor = false;
			DisplayAllStudentsButton.Click += DisplayAllStudentsButton_Click;
			// 
			// AddAStudentButton
			// 
			AddAStudentButton.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			AddAStudentButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
			AddAStudentButton.BackColor = SystemColors.ScrollBar;
			AddAStudentButton.Font = new Font("Segoe Fluent Icons", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
			AddAStudentButton.Location = new Point(142, 91);
			AddAStudentButton.Margin = new Padding(0);
			AddAStudentButton.Name = "AddAStudentButton";
			AddAStudentButton.Size = new Size(242, 86);
			AddAStudentButton.TabIndex = 4;
			AddAStudentButton.Text = "Add a Student";
			AddAStudentButton.UseVisualStyleBackColor = false;
			AddAStudentButton.Click += AddAStudentButton_Click;
			// 
			// AddaCourseButton
			// 
			AddaCourseButton.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			AddaCourseButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
			AddaCourseButton.BackColor = SystemColors.ScrollBar;
			AddaCourseButton.Font = new Font("Segoe Fluent Icons", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
			AddaCourseButton.Location = new Point(434, 91);
			AddaCourseButton.Margin = new Padding(0);
			AddaCourseButton.Name = "AddaCourseButton";
			AddaCourseButton.Size = new Size(242, 86);
			AddaCourseButton.TabIndex = 8;
			AddaCourseButton.Text = "Add a Course";
			AddaCourseButton.UseVisualStyleBackColor = false;
			AddaCourseButton.Click += AddaCourseButton_Click;
			// 
			// DisplayAllCoursesButton
			// 
			DisplayAllCoursesButton.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			DisplayAllCoursesButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
			DisplayAllCoursesButton.BackColor = SystemColors.ScrollBar;
			DisplayAllCoursesButton.Font = new Font("Segoe Fluent Icons", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
			DisplayAllCoursesButton.Location = new Point(434, 180);
			DisplayAllCoursesButton.Margin = new Padding(0);
			DisplayAllCoursesButton.Name = "DisplayAllCoursesButton";
			DisplayAllCoursesButton.Size = new Size(242, 86);
			DisplayAllCoursesButton.TabIndex = 7;
			DisplayAllCoursesButton.Text = "Display All Courses";
			DisplayAllCoursesButton.UseVisualStyleBackColor = false;
			DisplayAllCoursesButton.Click += DisplayAllCoursesButton_Click;
			// 
			// WhoIsInaCourseButton
			// 
			WhoIsInaCourseButton.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			WhoIsInaCourseButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
			WhoIsInaCourseButton.BackColor = SystemColors.ScrollBar;
			WhoIsInaCourseButton.Font = new Font("Segoe Fluent Icons", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
			WhoIsInaCourseButton.Location = new Point(434, 270);
			WhoIsInaCourseButton.Margin = new Padding(0);
			WhoIsInaCourseButton.Name = "WhoIsInaCourseButton";
			WhoIsInaCourseButton.Size = new Size(242, 86);
			WhoIsInaCourseButton.TabIndex = 6;
			WhoIsInaCourseButton.Text = "Who Is In a Course";
			WhoIsInaCourseButton.UseVisualStyleBackColor = false;
			WhoIsInaCourseButton.Click += WhoIsInaCourseButton_Click;
			// 
			// ExitButton
			// 
			ExitButton.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			ExitButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
			ExitButton.BackColor = SystemColors.ScrollBar;
			ExitButton.Font = new Font("Segoe Fluent Icons", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
			ExitButton.Location = new Point(434, 357);
			ExitButton.Margin = new Padding(0);
			ExitButton.Name = "ExitButton";
			ExitButton.Size = new Size(242, 86);
			ExitButton.TabIndex = 5;
			ExitButton.Text = "Exit";
			ExitButton.UseVisualStyleBackColor = false;
			ExitButton.Click += ExitButton_Click;
			// 
			// CourseTrackingSystemForm
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(782, 470);
			Controls.Add(AddaCourseButton);
			Controls.Add(DisplayAllCoursesButton);
			Controls.Add(WhoIsInaCourseButton);
			Controls.Add(ExitButton);
			Controls.Add(AddAStudentButton);
			Controls.Add(DisplayAllStudentsButton);
			Controls.Add(EnrollaStudentinaCourseButton);
			Controls.Add(whatCoursesaStudentEnrolledInButton);
			Controls.Add(label1);
			Name = "CourseTrackingSystemForm";
			Text = "Course Tracking System Project 1";
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label label1;
		private Button whatCoursesaStudentEnrolledInButton;
		private Button EnrollaStudentinaCourseButton;
		private Button DisplayAllStudentsButton;
		private Button AddAStudentButton;
		private Button AddaCourseButton;
		private Button DisplayAllCoursesButton;
		private Button WhoIsInaCourseButton;
		private Button ExitButton;
	}
}