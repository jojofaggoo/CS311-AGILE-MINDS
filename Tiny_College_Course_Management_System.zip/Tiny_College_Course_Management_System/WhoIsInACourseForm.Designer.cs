﻿namespace Tiny_College_Course_Management_System
{
	partial class WhoIsInACourseForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			courseLabel = new Label();
			courseComboBox = new ComboBox();
			studentsDataGridView = new DataGridView();
			closeButton = new Button();
			((System.ComponentModel.ISupportInitialize)studentsDataGridView).BeginInit();
			SuspendLayout();
			// 
			// courseLabel
			// 
			courseLabel.AutoSize = true;
			courseLabel.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			courseLabel.Location = new Point(16, 12);
			courseLabel.Name = "courseLabel";
			courseLabel.Size = new Size(133, 28);
			courseLabel.TabIndex = 1;
			courseLabel.Text = "Select Course:";
			// 
			// courseComboBox
			// 
			courseComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
			courseComboBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			courseComboBox.FormattingEnabled = true;
			courseComboBox.Location = new Point(164, 12);
			courseComboBox.Name = "courseComboBox";
			courseComboBox.Size = new Size(600, 36);
			courseComboBox.TabIndex = 2;
			courseComboBox.SelectedIndexChanged += courseComboBox_SelectedIndexChanged;
			// 
			// studentsDataGridView
			// 
			studentsDataGridView.AllowUserToAddRows = false;
			studentsDataGridView.AllowUserToDeleteRows = false;
			studentsDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
			studentsDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			studentsDataGridView.Location = new Point(16, 72);
			studentsDataGridView.Name = "studentsDataGridView";
			studentsDataGridView.ReadOnly = true;
			studentsDataGridView.RowHeadersWidth = 51;
			studentsDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
			studentsDataGridView.Size = new Size(776, 280);
			studentsDataGridView.TabIndex = 3;
			// 
			// closeButton
			// 
			closeButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			closeButton.Location = new Point(326, 370);
			closeButton.Name = "closeButton";
			closeButton.Size = new Size(120, 40);
			closeButton.TabIndex = 4;
			closeButton.Text = "&Close";
			closeButton.UseVisualStyleBackColor = true;
			closeButton.Click += closeButton_Click;
			// 
			// WhoIsInACourseForm
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(800, 425);
			Controls.Add(closeButton);
			Controls.Add(studentsDataGridView);
			Controls.Add(courseComboBox);
			Controls.Add(courseLabel);
			Name = "WhoIsInACourseForm";
			Text = "Who Is In A Course ";
			Load += WhoIsInACourseForm_Load;
			((System.ComponentModel.ISupportInitialize)studentsDataGridView).EndInit();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion
		private Label courseLabel;
		private ComboBox courseComboBox;
		private DataGridView studentsDataGridView;
		private Button closeButton;
	}
}
