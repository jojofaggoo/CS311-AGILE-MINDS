﻿/*
CISS 311 - ADVANCED AGILE SOFTWARE DEVELOPMENT
Instructor: Michael Miracle
 
Team 2: The Agile Minds
Members: Audrey Gamble, Jahmai Hawkins, Sandrin Tebo, Tiny Walters, Jacob Decker, Joe Fague
Course Project 2: Tiny College Course Mgmt database
 
11/25/2025
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tiny_College_Course_Management_System
{
	public partial class CourseTrackingSystemForm : Form
	{
		public CourseTrackingSystemForm()
		{
			InitializeComponent();
		}

		private void AddAStudentButton_Click(object sender, EventArgs e)//opens the AddAStudentForm
		{
			AddAStudentForm addAStudentForm = new AddAStudentForm();
			addAStudentForm.ShowDialog();
		}

		private void DisplayAllStudentsButton_Click(object sender, EventArgs e)//opens the AllStudentsForm
		{
			AllStudentsForm allStudentsForm = new AllStudentsForm();
			allStudentsForm.ShowDialog();
		}

		private void EnrollaStudentinaCourseButton_Click(object sender, EventArgs e)//opens the EnrollStudentInCourseForm
		{
			EnrollStudentInCourseForm enrollStudentInCourseForm = new EnrollStudentInCourseForm();
			enrollStudentInCourseForm.ShowDialog();
		}

		private void whatCoursesaStudentEnrolledInButton_Click(object sender, EventArgs e)//opens the WhatCoursesAStudentEnrolledForm
		{
			WhatCoursesAStudentEnrolledForm whatCoursesAStudentEnrolledForm = new WhatCoursesAStudentEnrolledForm();
			whatCoursesAStudentEnrolledForm.ShowDialog();
		}

		private void AddaCourseButton_Click(object sender, EventArgs e)//opens the AddACourseForm
		{
			AddACourseForm addACourseForm = new AddACourseForm();
			addACourseForm.ShowDialog();
		}

		private void DisplayAllCoursesButton_Click(object sender, EventArgs e)//opens the AllCoursesForm
		{
			AllCoursesForm allCoursesForm = new AllCoursesForm();
			allCoursesForm.ShowDialog();
		}

		private void WhoIsInaCourseButton_Click(object sender, EventArgs e)//opens the WhoIsInACourseForm
		{
			WhoIsInACourseForm whoIsInACourseForm = new WhoIsInACourseForm();
			whoIsInACourseForm.ShowDialog();
		}

		private void ExitButton_Click(object sender, EventArgs e)
		{
			Close();
		}
	}
}
