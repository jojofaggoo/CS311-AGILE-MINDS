﻿/*
CISS 311 - ADVANCED AGILE SOFTWARE DEVELOPMENT
Instructor: Michael Miracle
 
Team 2: The Agile Minds
Members: Audrey Gamble, Jahmai Hawkins, Sandrin Tebo, Tiny Walters, Jacob Decker, Joe Fague
Course Project 2: Tiny College Course Mgmt database
 
11/25/2025
*/
//This form allows the user to add a new course to the Tiny College Course Management System database.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tiny_College_Course_Management_System
{
	public partial class AddACourseForm : Form
	{
		public AddACourseForm()
		{
			InitializeComponent();
		}

		private void addCourseButton_Click(object sender, EventArgs e)// Add Course to Database
		{
			if (!int.TryParse(instructorIDTextBox.Text, out int instructorID) || instructorID <= 0)// Instructor ID must be a positive integer
				{
					feedbackToolStripStatusLabel.Text = ("Enter a valid Instructor ID.");// Feedback message

					instructorIDTextBox.Focus();// Set focus to Instructor ID textbox
					return;
				}

			if (!int.TryParse(maxSeatsTextBox.Text, out int maxSeats) || maxSeats <= 0)// Max Seats must be a positive integer
				{
					feedbackToolStripStatusLabel.Text = ("Enter a positive number for Max Seats (greater than 0).");
					
					maxSeatsTextBox.Focus();
					return; 
				}

			if (!int.TryParse(availableSeatsTextBox.Text, out int availableSeats) || availableSeats < 0)// Available Seats must be 0 or greater
				{
					feedbackToolStripStatusLabel.Text = ("Enter a valid number for Available Seats (0 or greater).");
					
					availableSeatsTextBox.Focus();
					return;
				}

				if (availableSeats > maxSeats)// Available Seats can't exceed Max Seats
				{
					feedbackToolStripStatusLabel.Text=("Available Seats can't be greater than Max Seats.");
					availableSeatsTextBox.Focus();
					return;
				}

				if (!int.TryParse(creditHoursTextBox.Text, out int creditHours) || creditHours <= 0)// Credit Hours must be a positive integer
				{
					feedbackToolStripStatusLabel.Text = ("Enter a valid number for Credit Hours (greater than 0).");

					creditHoursTextBox.Focus();
					return;
				}

				using SqlConnection conn = new(Properties.Settings.Default.connString);// Database connection
				using SqlCommand comd = new("INSERT INTO Courses(Title, InstructorID, MaxSeats, AvailableSeats, IsActive, CreditHours) " +
					"VALUES (@title, @instructorID, @maxSeats, @availableSeats, @isActive, @creditHours)", conn);// SQL command to insert a new course

				conn.Open();// Open the connection
				comd.Parameters.AddWithValue("@title", courseTitleTextBox.Text);// Add parameters for SQL command
				comd.Parameters.AddWithValue("@instructorID", instructorID);//Gets the instructor ID
				comd.Parameters.AddWithValue("@maxSeats", maxSeats);// Gets the max seats
				comd.Parameters.AddWithValue("@availableSeats", availableSeats);// Gets the available seats
				comd.Parameters.AddWithValue("@isActive", isActiveCheckBox.Checked ? 1 : 0);// Gets whether the course is active
				comd.Parameters.AddWithValue("@creditHours", creditHours);// Gets the credit hours

				comd.ExecuteNonQuery();// Execute the command

				MessageBox.Show("Course added successfully!");//Confirmation message

				// Clear the form for new entry
				courseTitleTextBox.Clear();
				instructorIDTextBox.Clear();
				maxSeatsTextBox.Clear();
				availableSeatsTextBox.Clear();
				creditHoursTextBox.Clear();
				isActiveCheckBox.Checked = false;
				courseTitleTextBox.Focus();
			}
		private void closeButton_Click(object sender, EventArgs e)
		{
			Close();
		}

	}
}
