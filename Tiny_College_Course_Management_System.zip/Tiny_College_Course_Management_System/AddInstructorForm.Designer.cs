namespace Tiny_College_Course_Management_System
{
	partial class AddInstructorForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			titleLabel = new Label();
			instructorNameLabel = new Label();
			newInstructorNameTextBox = new TextBox();
			instructorEmailLabel = new Label();
			newInstructorEmailTextBox = new TextBox();
			addInstructorButton = new Button();
			closeButton = new Button();
			instructorGroupBox = new GroupBox();
			statusStrip = new StatusStrip();
			feedbackToolStripStatusLabel = new ToolStripStatusLabel();
			instructorGroupBox.SuspendLayout();
			statusStrip.SuspendLayout();
			SuspendLayout();
			// 
			// titleLabel
			// 
			titleLabel.AutoSize = true;
			titleLabel.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
			titleLabel.Location = new Point(12, 9);
			titleLabel.Name = "titleLabel";
			titleLabel.Size = new Size(192, 31);
			titleLabel.TabIndex = 0;
			titleLabel.Text = "Add an Instructor";
			// 
			// instructorNameLabel
			// 
			instructorNameLabel.AutoSize = true;
			instructorNameLabel.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			instructorNameLabel.Location = new Point(20, 40);
			instructorNameLabel.Name = "instructorNameLabel";
			instructorNameLabel.Size = new Size(157, 28);
			instructorNameLabel.TabIndex = 1;
			instructorNameLabel.Text = "Instructor Name:";
			// 
			// newInstructorNameTextBox
			// 
			newInstructorNameTextBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			newInstructorNameTextBox.Location = new Point(20, 75);
			newInstructorNameTextBox.MaxLength = 50;
			newInstructorNameTextBox.Name = "newInstructorNameTextBox";
			newInstructorNameTextBox.Size = new Size(450, 34);
			newInstructorNameTextBox.TabIndex = 2;
			// 
			// instructorEmailLabel
			// 
			instructorEmailLabel.AutoSize = true;
			instructorEmailLabel.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			instructorEmailLabel.Location = new Point(20, 125);
			instructorEmailLabel.Name = "instructorEmailLabel";
			instructorEmailLabel.Size = new Size(63, 28);
			instructorEmailLabel.TabIndex = 3;
			instructorEmailLabel.Text = "Email:";
			// 
			// newInstructorEmailTextBox
			// 
			newInstructorEmailTextBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			newInstructorEmailTextBox.Location = new Point(20, 160);
			newInstructorEmailTextBox.MaxLength = 100;
			newInstructorEmailTextBox.Name = "newInstructorEmailTextBox";
			newInstructorEmailTextBox.Size = new Size(450, 34);
			newInstructorEmailTextBox.TabIndex = 4;
			// 
			// addInstructorButton
			// 
			addInstructorButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			addInstructorButton.Location = new Point(120, 320);
			addInstructorButton.Name = "addInstructorButton";
			addInstructorButton.Size = new Size(180, 45);
			addInstructorButton.TabIndex = 5;
			addInstructorButton.Text = "&Add Instructor";
			addInstructorButton.UseVisualStyleBackColor = true;
			addInstructorButton.Click += addInstructorButton_Click;
			// 
			// closeButton
			// 
			closeButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			closeButton.Location = new Point(320, 320);
			closeButton.Name = "closeButton";
			closeButton.Size = new Size(120, 45);
			closeButton.TabIndex = 6;
			closeButton.Text = "&Close";
			closeButton.UseVisualStyleBackColor = true;
			closeButton.Click += closeButton_Click;
			// 
			// instructorGroupBox
			// 
			instructorGroupBox.Controls.Add(instructorNameLabel);
			instructorGroupBox.Controls.Add(newInstructorNameTextBox);
			instructorGroupBox.Controls.Add(instructorEmailLabel);
			instructorGroupBox.Controls.Add(newInstructorEmailTextBox);
			instructorGroupBox.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
			instructorGroupBox.Location = new Point(12, 60);
			instructorGroupBox.Name = "instructorGroupBox";
			instructorGroupBox.Size = new Size(500, 240);
			instructorGroupBox.TabIndex = 7;
			instructorGroupBox.TabStop = false;
			instructorGroupBox.Text = "Instructor Information";
			// 
			// statusStrip
			// 
			statusStrip.ImageScalingSize = new Size(20, 20);
			statusStrip.Items.AddRange(new ToolStripItem[] { feedbackToolStripStatusLabel });
			statusStrip.Location = new Point(0, 386);
			statusStrip.Name = "statusStrip";
			statusStrip.Size = new Size(524, 24);
			statusStrip.TabIndex = 8;
			statusStrip.Text = "statusStrip1";
			// 
			// feedbackToolStripStatusLabel
			// 
			feedbackToolStripStatusLabel.Name = "feedbackToolStripStatusLabel";
			feedbackToolStripStatusLabel.Size = new Size(0, 18);
			// 
			// AddInstructorForm
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(524, 410);
			Controls.Add(statusStrip);
			Controls.Add(instructorGroupBox);
			Controls.Add(closeButton);
			Controls.Add(addInstructorButton);
			Controls.Add(titleLabel);
			Name = "AddInstructorForm";
			Text = "Add Instructor";
			instructorGroupBox.ResumeLayout(false);
			instructorGroupBox.PerformLayout();
			statusStrip.ResumeLayout(false);
			statusStrip.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label titleLabel;
		private Label instructorNameLabel;
		private TextBox newInstructorNameTextBox;
		private Label instructorEmailLabel;
		private TextBox newInstructorEmailTextBox;
		private Button addInstructorButton;
		private Button closeButton;
		private GroupBox instructorGroupBox;
		private StatusStrip statusStrip;
		private ToolStripStatusLabel feedbackToolStripStatusLabel;
	}
}
