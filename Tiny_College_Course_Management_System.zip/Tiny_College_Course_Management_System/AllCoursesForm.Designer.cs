﻿namespace Tiny_College_Course_Management_System
{
	partial class AllCoursesForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			coursesDataGridView = new DataGridView();
			titleLabel = new Label();
			closeButton = new Button();
			allCoursesGroupBox = new GroupBox();
			((System.ComponentModel.ISupportInitialize)coursesDataGridView).BeginInit();
			allCoursesGroupBox.SuspendLayout();
			SuspendLayout();
			// 
			// coursesDataGridView
			// 
			coursesDataGridView.AllowUserToDeleteRows = false;
			coursesDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
			coursesDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			coursesDataGridView.Location = new Point(0, 0);
			coursesDataGridView.Name = "coursesDataGridView";
			coursesDataGridView.RowHeadersWidth = 51;
			coursesDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
			coursesDataGridView.Size = new Size(554, 324);
			coursesDataGridView.TabIndex = 0;
			// 
			// titleLabel
			// 
			titleLabel.AutoSize = true;
			titleLabel.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			titleLabel.Location = new Point(12, 9);
			titleLabel.Name = "titleLabel";
			titleLabel.Size = new Size(108, 28);
			titleLabel.TabIndex = 1;
			titleLabel.Text = "All Courses";
			// 
			// closeButton
			// 
			closeButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			closeButton.Location = new Point(214, 340);
			closeButton.Name = "closeButton";
			closeButton.Size = new Size(120, 40);
			closeButton.TabIndex = 3;
			closeButton.Text = "&Close";
			closeButton.UseVisualStyleBackColor = true;
			closeButton.Click += closeButton_Click;
			// 
			// allCoursesGroupBox
			// 
			allCoursesGroupBox.Controls.Add(closeButton);
			allCoursesGroupBox.Controls.Add(coursesDataGridView);
			allCoursesGroupBox.Location = new Point(12, 40);
			allCoursesGroupBox.Name = "allCoursesGroupBox";
			allCoursesGroupBox.Size = new Size(559, 380);
			allCoursesGroupBox.TabIndex = 4;
			allCoursesGroupBox.TabStop = false;
			allCoursesGroupBox.Text = "All Courses";
			// 
			// AllCoursesForm
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(583, 438);
			Controls.Add(titleLabel);
			Controls.Add(allCoursesGroupBox);
			Name = "AllCoursesForm";
			Text = "All Courses";
			Load += AllCoursesForm_Load;
			((System.ComponentModel.ISupportInitialize)coursesDataGridView).EndInit();
			allCoursesGroupBox.ResumeLayout(false);
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private DataGridView coursesDataGridView;
		private Label titleLabel;
		private Button closeButton;
		private GroupBox allCoursesGroupBox;
	}
}
