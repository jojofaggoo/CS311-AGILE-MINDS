﻿namespace Tiny_College_Course_Management_System
{
	partial class AllStudentsForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			studentsDataGridView = new DataGridView();
			closeButton = new Button();
			allStudentsGroupBox = new GroupBox();
			((System.ComponentModel.ISupportInitialize)studentsDataGridView).BeginInit();
			SuspendLayout();
			// 
			// studentsDataGridView
			// 
			studentsDataGridView.AllowUserToAddRows = false;
			studentsDataGridView.AllowUserToDeleteRows = false;
			studentsDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
			studentsDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			studentsDataGridView.Location = new Point(12, 51);
			studentsDataGridView.Name = "studentsDataGridView";
			studentsDataGridView.ReadOnly = true;
			studentsDataGridView.RowHeadersWidth = 51;
			studentsDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
			studentsDataGridView.Size = new Size(524, 339);
			studentsDataGridView.TabIndex = 0;
			// 
			// closeButton
			// 
			closeButton.BackColor = SystemColors.ScrollBar;
			closeButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			closeButton.Location = new Point(205, 406);
			closeButton.Name = "closeButton";
			closeButton.Size = new Size(120, 40);
			closeButton.TabIndex = 3;
			closeButton.Text = "&Close";
			closeButton.UseVisualStyleBackColor = false;
			closeButton.Click += closeButton_Click;
			// 
			// allStudentsGroupBox
			// 
			allStudentsGroupBox.Location = new Point(12, 25);
			allStudentsGroupBox.Name = "allStudentsGroupBox";
			allStudentsGroupBox.Size = new Size(530, 375);
			allStudentsGroupBox.TabIndex = 4;
			allStudentsGroupBox.TabStop = false;
			allStudentsGroupBox.Text = "All Students";
			// 
			// AllStudentsForm
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(554, 460);
			Controls.Add(closeButton);
			Controls.Add(studentsDataGridView);
			Controls.Add(allStudentsGroupBox);
			Name = "AllStudentsForm";
			Text = "All Students";
			Load += AllStudentsForm_Load;
			((System.ComponentModel.ISupportInitialize)studentsDataGridView).EndInit();
			ResumeLayout(false);
		}

		#endregion

		private DataGridView studentsDataGridView;
		private Button closeButton;
		private GroupBox allStudentsGroupBox;
	}
}
