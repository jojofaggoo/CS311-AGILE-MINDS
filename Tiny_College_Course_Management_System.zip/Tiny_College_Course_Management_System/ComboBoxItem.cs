﻿/*
CISS 311 - ADVANCED AGILE SOFTWARE DEVELOPMENT
Instructor: Michael Miracle
 
Team 2: The Agile Minds
Members: Audrey Gamble, Jahmai Hawkins, Sandrin Tebo, Tiny Walters, Jacob Decker, Joe Fague
Course Project 2: Tiny College Course Mgmt database
 
11/25/2025
*/using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tiny_College_Course_Management_System
{
	internal class ComboBoxItem//Helper class to represent the item in the combo box
	{
		public string Value { get; set; }//Property to hold the value associated with the combo box item
		public string Text { get; set; }//Property to hold the display text for the combo box item
		public override string ToString()//Overrides the ToString method to return the display text
		{
			return Text;
		}
	}
}
