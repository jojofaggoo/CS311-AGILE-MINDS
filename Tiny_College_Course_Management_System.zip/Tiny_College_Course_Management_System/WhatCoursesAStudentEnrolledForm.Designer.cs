﻿namespace Tiny_College_Course_Management_System
{
	partial class WhatCoursesAStudentEnrolledForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			studentIdLabel = new Label();
			studentIdTextBox = new TextBox();
			studentInfoLabel = new Label();
			coursesDataGridView = new DataGridView();
			creditHoursLabel = new Label();
			totalCreditsValueLabel = new Label();
			closeButton = new Button();
			studentGroupBox = new GroupBox();
			coursesGroupBox = new GroupBox();
			feedbackToolStripStatusLabel = new StatusStrip();
			statusLabel = new ToolStripStatusLabel();
			titleLabel = new Label();
			((System.ComponentModel.ISupportInitialize)coursesDataGridView).BeginInit();
			studentGroupBox.SuspendLayout();
			coursesGroupBox.SuspendLayout();
			feedbackToolStripStatusLabel.SuspendLayout();
			SuspendLayout();
			// 
			// studentIdLabel
			// 
			studentIdLabel.AutoSize = true;
			studentIdLabel.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			studentIdLabel.Location = new Point(20, 35);
			studentIdLabel.Name = "studentIdLabel";
			studentIdLabel.Size = new Size(108, 28);
			studentIdLabel.TabIndex = 1;
			studentIdLabel.Text = "Student ID:";
			// 
			// studentIdTextBox
			// 
			studentIdTextBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			studentIdTextBox.Location = new Point(132, 32);
			studentIdTextBox.Name = "studentIdTextBox";
			studentIdTextBox.Size = new Size(150, 34);
			studentIdTextBox.TabIndex = 2;
			studentIdTextBox.TextChanged += studentIdTextBox_TextChanged;
			// 
			// studentInfoLabel
			// 
			studentInfoLabel.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			studentInfoLabel.ForeColor = SystemColors.ControlText;
			studentInfoLabel.Location = new Point(309, 17);
			studentInfoLabel.Name = "studentInfoLabel";
			studentInfoLabel.Size = new Size(411, 152);
			studentInfoLabel.TabIndex = 3;
			studentInfoLabel.Text = "Enter your student ID to view courses";
			studentInfoLabel.TextAlign = ContentAlignment.MiddleCenter;
			// 
			// coursesDataGridView
			// 
			coursesDataGridView.AllowUserToAddRows = false;
			coursesDataGridView.AllowUserToDeleteRows = false;
			coursesDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
			coursesDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			coursesDataGridView.Location = new Point(20, 35);
			coursesDataGridView.Name = "coursesDataGridView";
			coursesDataGridView.ReadOnly = true;
			coursesDataGridView.RowHeadersWidth = 51;
			coursesDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
			coursesDataGridView.Size = new Size(700, 250);
			coursesDataGridView.TabIndex = 4;
			// 
			// creditHoursLabel
			// 
			creditHoursLabel.AutoSize = true;
			creditHoursLabel.Font = new Font("Segoe UI", 12F);
			creditHoursLabel.Location = new Point(20, 126);
			creditHoursLabel.Name = "creditHoursLabel";
			creditHoursLabel.Size = new Size(178, 28);
			creditHoursLabel.TabIndex = 5;
			creditHoursLabel.Text = "Total Credit Hours :";
			// 
			// totalCreditsValueLabel
			// 
			totalCreditsValueLabel.AutoSize = true;
			totalCreditsValueLabel.Font = new Font("Segoe UI", 12F);
			totalCreditsValueLabel.ForeColor = Color.Black;
			totalCreditsValueLabel.Location = new Point(221, 126);
			totalCreditsValueLabel.Name = "totalCreditsValueLabel";
			totalCreditsValueLabel.Size = new Size(23, 28);
			totalCreditsValueLabel.TabIndex = 6;
			totalCreditsValueLabel.Text = "0";
			// 
			// closeButton
			// 
			closeButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			closeButton.Location = new Point(266, 544);
			closeButton.Name = "closeButton";
			closeButton.Size = new Size(120, 45);
			closeButton.TabIndex = 7;
			closeButton.Text = "&Close";
			closeButton.UseVisualStyleBackColor = true;
			closeButton.Click += closeButton_Click;
			// 
			// studentGroupBox
			// 
			studentGroupBox.Controls.Add(studentIdLabel);
			studentGroupBox.Controls.Add(creditHoursLabel);
			studentGroupBox.Controls.Add(totalCreditsValueLabel);
			studentGroupBox.Controls.Add(studentIdTextBox);
			studentGroupBox.Controls.Add(studentInfoLabel);
			studentGroupBox.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
			studentGroupBox.Location = new Point(12, 43);
			studentGroupBox.Name = "studentGroupBox";
			studentGroupBox.Size = new Size(760, 172);
			studentGroupBox.TabIndex = 8;
			studentGroupBox.TabStop = false;
			studentGroupBox.Text = "Student Information";
			// 
			// coursesGroupBox
			// 
			coursesGroupBox.Controls.Add(coursesDataGridView);
			coursesGroupBox.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
			coursesGroupBox.Location = new Point(12, 225);
			coursesGroupBox.Name = "coursesGroupBox";
			coursesGroupBox.Size = new Size(760, 302);
			coursesGroupBox.TabIndex = 9;
			coursesGroupBox.TabStop = false;
			coursesGroupBox.Text = "Enrolled Courses";
			// 
			// feedbackToolStripStatusLabel
			// 
			feedbackToolStripStatusLabel.ImageScalingSize = new Size(20, 20);
			feedbackToolStripStatusLabel.Items.AddRange(new ToolStripItem[] { statusLabel });
			feedbackToolStripStatusLabel.Location = new Point(0, 618);
			feedbackToolStripStatusLabel.Name = "feedbackToolStripStatusLabel";
			feedbackToolStripStatusLabel.Size = new Size(784, 26);
			feedbackToolStripStatusLabel.TabIndex = 10;
			feedbackToolStripStatusLabel.Text = "statusStrip1";
			// 
			// statusLabel
			// 
			statusLabel.Name = "statusLabel";
			statusLabel.Size = new Size(177, 20);
			statusLabel.Text = "Enter Student ID to begin";
			// 
			// titleLabel
			// 
			titleLabel.AutoSize = true;
			titleLabel.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
			titleLabel.Location = new Point(167, 9);
			titleLabel.Name = "titleLabel";
			titleLabel.Size = new Size(313, 31);
			titleLabel.TabIndex = 0;
			titleLabel.Text = "View Grades and Enrollments";
			// 
			// WhatCoursesAStudentEnrolledForm
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(784, 644);
			Controls.Add(feedbackToolStripStatusLabel);
			Controls.Add(coursesGroupBox);
			Controls.Add(studentGroupBox);
			Controls.Add(closeButton);
			Controls.Add(titleLabel);
			Name = "WhatCoursesAStudentEnrolledForm";
			Text = "Student Course Enrollment & Grades";
			((System.ComponentModel.ISupportInitialize)coursesDataGridView).EndInit();
			studentGroupBox.ResumeLayout(false);
			studentGroupBox.PerformLayout();
			coursesGroupBox.ResumeLayout(false);
			feedbackToolStripStatusLabel.ResumeLayout(false);
			feedbackToolStripStatusLabel.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion
		private Label studentIdLabel;
		private TextBox studentIdTextBox;
		private Label studentInfoLabel;
		private DataGridView coursesDataGridView;
		private Label creditHoursLabel;
		private Label totalCreditsValueLabel;
		private Button closeButton;
		private GroupBox studentGroupBox;
		private GroupBox coursesGroupBox;
		private StatusStrip feedbackToolStripStatusLabel;
		private ToolStripStatusLabel statusLabel;
		private Label titleLabel;
	}
}
