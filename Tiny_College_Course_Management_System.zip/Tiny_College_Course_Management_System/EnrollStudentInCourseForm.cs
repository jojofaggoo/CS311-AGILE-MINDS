﻿/*
CISS 311 - ADVANCED AGILE SOFTWARE DEVELOPMENT
Instructor: Michael Miracle
 
Team 2: The Agile Minds
Members: Audrey Gamble, Jahmai Hawkins, Sandrin Tebo, Tiny Walters, Jacob Decker, Joe Fague
Course Project 2: Tiny College Course Mgmt database
 
11/25/2025
*/
//This form allows administrators to enroll students in courses using TextBox for student ID and course search
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Tiny_College_Course_Management_System
{
	public partial class EnrollStudentInCourseForm : Form
	{
		private int currentStudentId = 0;
		private string currentStudentName = "";

		public EnrollStudentInCourseForm()
		{
			InitializeComponent();
		}

		private void studentIdTextBox_TextChanged(object sender, EventArgs e)
		{
			// Validate student ID as user types
			if (string.IsNullOrWhiteSpace(studentIdTextBox.Text))
			{
				studentInfoLabel.Text = "Enter a student ID to begin";
				studentInfoLabel.ForeColor = SystemColors.ControlText;
				courseSearchTextBox.Enabled = false;
				searchButton.Enabled = false;
				enrollButton.Enabled = false;
				currentStudentId = 0;
				currentStudentName = "";
				statusLabel.Text = "Enter Student ID to begin";
				return;
			}

			if (!int.TryParse(studentIdTextBox.Text, out int studentId) || studentId <= 0)
			{
				studentInfoLabel.Text = "Invalid Student ID. Please enter a positive number.";
				studentInfoLabel.ForeColor = Color.Red;
				courseSearchTextBox.Enabled = false;
				searchButton.Enabled = false;
				enrollButton.Enabled = false;
				currentStudentId = 0;
				currentStudentName = "";
				statusLabel.Text = "Invalid Student ID";
				return;
			}

			// Look up student in database
			try
			{
				using SqlConnection conn = new(Properties.Settings.Default.connString);
				conn.Open();

				using SqlCommand cmd = new("SELECT StudentName, Email FROM Students WHERE StudentID = @StudentID", conn);
				cmd.Parameters.AddWithValue("@StudentID", studentId);

				using SqlDataReader reader = cmd.ExecuteReader();
				if (reader.Read())
				{
					currentStudentId = studentId;
					currentStudentName = reader.GetString(0);
					string email = reader.GetString(1);

					studentInfoLabel.Text = $"Student Found:\nName: {currentStudentName}\nEmail: {email}";
					studentInfoLabel.ForeColor = Color.Green;
					courseSearchTextBox.Enabled = true;
					searchButton.Enabled = true;
					statusLabel.Text = $"Student {currentStudentName} selected. Search for courses.";

					// Auto-search for all courses when student is found
					SearchCourses("");
				}
				else
				{
					studentInfoLabel.Text = $"Student ID {studentId} not found in the system.";
					studentInfoLabel.ForeColor = Color.Red;
					courseSearchTextBox.Enabled = false;
					searchButton.Enabled = false;
					enrollButton.Enabled = false;
					currentStudentId = 0;
					currentStudentName = "";
					statusLabel.Text = "Student not found";
					coursesDataGridView.DataSource = null;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Error looking up student: {ex.Message}", "Database Error",
					MessageBoxButtons.OK, MessageBoxIcon.Error);
				studentInfoLabel.Text = "Error looking up student";
				studentInfoLabel.ForeColor = Color.Red;
			}
		}

		private void searchButton_Click(object sender, EventArgs e)
		{
			SearchCourses(courseSearchTextBox.Text.Trim());
		}

		private void SearchCourses(string searchTerm)
		{
			try
			{
				using SqlConnection conn = new(Properties.Settings.Default.connString);
				conn.Open();

				string query = @"
					SELECT 
						c.CourseID,
						c.Title,
						i.InstructorName,
						c.AvailableSeats,
						c.MaxSeats,
						c.CreditHours,
						CASE WHEN c.AvailableSeats > 0 THEN 'Yes' ELSE 'No' END AS SeatsAvailable
					FROM Courses c
					INNER JOIN Instructors i ON c.InstructorID = i.InstructorID
					WHERE c.IsActive = 1";

				// Add search filter if search term provided
				if (!string.IsNullOrWhiteSpace(searchTerm))
				{
					query += " AND c.Title LIKE @SearchTerm";
				}

				query += " ORDER BY c.Title";

				using SqlCommand cmd = new(query, conn);
				if (!string.IsNullOrWhiteSpace(searchTerm))
				{
					cmd.Parameters.AddWithValue("@SearchTerm", "%" + searchTerm + "%");
				}

				DataTable dt = new DataTable();
				using SqlDataAdapter adapter = new SqlDataAdapter(cmd);
				adapter.Fill(dt);

				if (dt.Rows.Count > 0)
				{
					coursesDataGridView.DataSource = dt;

					// Format columns
					coursesDataGridView.Columns["CourseID"].HeaderText = "Course ID";
					coursesDataGridView.Columns["CourseID"].Width = 80;
					coursesDataGridView.Columns["Title"].HeaderText = "Course Title";
					coursesDataGridView.Columns["InstructorName"].HeaderText = "Instructor";
					coursesDataGridView.Columns["AvailableSeats"].HeaderText = "Available";
					coursesDataGridView.Columns["AvailableSeats"].Width = 80;
					coursesDataGridView.Columns["MaxSeats"].HeaderText = "Max";
					coursesDataGridView.Columns["MaxSeats"].Width = 60;
					coursesDataGridView.Columns["CreditHours"].HeaderText = "Credits";
					coursesDataGridView.Columns["CreditHours"].Width = 70;
					coursesDataGridView.Columns["SeatsAvailable"].HeaderText = "Seats?";
					coursesDataGridView.Columns["SeatsAvailable"].Width = 70;

					enrollButton.Enabled = true;
					statusLabel.Text = $"Found {dt.Rows.Count} course(s). Select a course and click Enroll.";
				}
				else
				{
					coursesDataGridView.DataSource = null;
					enrollButton.Enabled = false;
					string message = string.IsNullOrWhiteSpace(searchTerm) 
						? "No active courses available." 
						: $"No courses found matching '{searchTerm}'.";
					statusLabel.Text = message;
					MessageBox.Show(message, "No Courses Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Error searching courses: {ex.Message}", "Database Error",
					MessageBoxButtons.OK, MessageBoxIcon.Error);
				statusLabel.Text = "Error searching courses";
			}
		}

		private void enrollButton_Click(object sender, EventArgs e)
		{
			// Validate student is selected
			if (currentStudentId == 0)
			{
				MessageBox.Show("Please enter a valid Student ID first.", "Validation Error",
					MessageBoxButtons.OK, MessageBoxIcon.Warning);
				studentIdTextBox.Focus();
				return;
			}

			// Validate course is selected
			if (coursesDataGridView.SelectedRows.Count == 0)
			{
				MessageBox.Show("Please select a course from the list.", "Validation Error",
					MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			DataGridViewRow selectedRow = coursesDataGridView.SelectedRows[0];
			int courseId = Convert.ToInt32(selectedRow.Cells["CourseID"].Value);
			string courseTitle = selectedRow.Cells["Title"].Value.ToString();
			int availableSeats = Convert.ToInt32(selectedRow.Cells["AvailableSeats"].Value);

			// Check if seats are available
			if (availableSeats <= 0)
			{
				MessageBox.Show($"There are no seats available in '{courseTitle}'.", "No Seats Available",
					MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			try
			{
				using SqlConnection conn = new(Properties.Settings.Default.connString);
				conn.Open();

				// Check if student is already enrolled
				using SqlCommand checkCmd = new("SELECT COUNT(*) FROM Registrations WHERE StudentID = @StudentID AND CourseID = @CourseID", conn);
				checkCmd.Parameters.AddWithValue("@StudentID", currentStudentId);
				checkCmd.Parameters.AddWithValue("@CourseID", courseId);
				int count = (int)checkCmd.ExecuteScalar();

				if (count > 0)
				{
					MessageBox.Show($"{currentStudentName} is already enrolled in '{courseTitle}'.", "Already Enrolled",
						MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}

				// Enroll student using transaction
				using SqlTransaction transaction = conn.BeginTransaction();
				try
				{
					// Insert registration
					using SqlCommand insertCmd = new("INSERT INTO Registrations (StudentID, CourseID, Grade) VALUES (@StudentID, @CourseID, NULL)", conn, transaction);
					insertCmd.Parameters.AddWithValue("@StudentID", currentStudentId);
					insertCmd.Parameters.AddWithValue("@CourseID", courseId);
					insertCmd.ExecuteNonQuery();

					// Update available seats
					using SqlCommand updateCmd = new("UPDATE Courses SET AvailableSeats = AvailableSeats - 1 WHERE CourseID = @CourseID", conn, transaction);
					updateCmd.Parameters.AddWithValue("@CourseID", courseId);
					updateCmd.ExecuteNonQuery();

					transaction.Commit();

					MessageBox.Show($"Successfully enrolled {currentStudentName} in '{courseTitle}'!", "Enrollment Successful",
						MessageBoxButtons.OK, MessageBoxIcon.Information);
					statusLabel.Text = $"Enrolled {currentStudentName} in {courseTitle}";

					// Refresh the course list to show updated seat availability
					SearchCourses(courseSearchTextBox.Text.Trim());
				}
				catch
				{
					transaction.Rollback();
					throw;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Error enrolling student: {ex.Message}", "Enrollment Error",
					MessageBoxButtons.OK, MessageBoxIcon.Error);
				statusLabel.Text = "Error enrolling student";
			}
		}

		private void closeButton_Click(object sender, EventArgs e)
		{
			Close();
		}
	}
}
