﻿/*
CISS 311 - ADVANCED AGILE SOFTWARE DEVELOPMENT
Instructor: Michael Miracle
 
Team 2: The Agile Minds
Members: Audrey Gamble, Jahmai Hawkins, Sandrin Tebo, Tiny Walters, Jacob Decker, Joe Fague
Course Project 2: Tiny College Course Mgmt database
 
11/25/2025
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using Microsoft.Data.SqlClient;

using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tiny_College_Course_Management_System
{
	public partial class AddAStudentForm : Form
	{
		public AddAStudentForm()
		{
			InitializeComponent();
		}

		private void closeButton_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void addStudentButton_Click(object sender, EventArgs e)
		{
			using SqlConnection conn = new(Properties.Settings.Default.connString);
			using SqlCommand comd = new("INSERT INTO Students(StudentName, Email) VALUES (@studentName, @studentEmail)", conn);
			conn.Open();
			comd.Parameters.AddWithValue("@studentName", newStudentNameTextBox.Text);
			comd.Parameters.AddWithValue("@studentEmail", newStudentEmailTextBox.Text);
			comd.ExecuteNonQuery();
			feedbackToolStripStatusLabel.Text = "Student added successfully.";
		}
	}
}
