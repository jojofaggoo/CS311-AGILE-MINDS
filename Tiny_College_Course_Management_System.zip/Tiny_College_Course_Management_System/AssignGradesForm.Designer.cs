namespace Tiny_College_Course_Management_System
{
	partial class AssignGradesForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			titleLabel = new Label();
			instructorIdLabel = new Label();
			instructorIdTextBox = new TextBox();
			loadCoursesButton = new Button();
			courseLabel = new Label();
			courseComboBox = new ComboBox();
			studentsDataGridView = new DataGridView();
			updateGradesButton = new Button();
			closeButton = new Button();
			instructorGroupBox = new GroupBox();
			courseGroupBox = new GroupBox();
			statusStrip = new StatusStrip();
			statusLabel = new ToolStripStatusLabel();
			((System.ComponentModel.ISupportInitialize)studentsDataGridView).BeginInit();
			instructorGroupBox.SuspendLayout();
			courseGroupBox.SuspendLayout();
			statusStrip.SuspendLayout();
			SuspendLayout();
			// 
			// titleLabel
			// 
			titleLabel.AutoSize = true;
			titleLabel.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
			titleLabel.Location = new Point(12, 9);
			titleLabel.Name = "titleLabel";
			titleLabel.Size = new Size(203, 41);
			titleLabel.TabIndex = 0;
			titleLabel.Text = "Assign Grades";
			// 
			// instructorIdLabel
			// 
			instructorIdLabel.AutoSize = true;
			instructorIdLabel.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			instructorIdLabel.Location = new Point(20, 35);
			instructorIdLabel.Name = "instructorIdLabel";
			instructorIdLabel.Size = new Size(127, 28);
			instructorIdLabel.TabIndex = 1;
			instructorIdLabel.Text = "Instructor ID:";
			// 
			// instructorIdTextBox
			// 
			instructorIdTextBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			instructorIdTextBox.Location = new Point(153, 32);
			instructorIdTextBox.Name = "instructorIdTextBox";
			instructorIdTextBox.Size = new Size(150, 34);
			instructorIdTextBox.TabIndex = 2;
			// 
			// loadCoursesButton
			// 
			loadCoursesButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			loadCoursesButton.Location = new Point(320, 28);
			loadCoursesButton.Name = "loadCoursesButton";
			loadCoursesButton.Size = new Size(180, 45);
			loadCoursesButton.TabIndex = 3;
			loadCoursesButton.Text = "&Load Courses";
			loadCoursesButton.UseVisualStyleBackColor = true;
			loadCoursesButton.Click += loadCoursesButton_Click;
			// 
			// courseLabel
			// 
			courseLabel.AutoSize = true;
			courseLabel.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			courseLabel.Location = new Point(20, 35);
			courseLabel.Name = "courseLabel";
			courseLabel.Size = new Size(133, 28);
			courseLabel.TabIndex = 4;
			courseLabel.Text = "Select Course:";
			// 
			// courseComboBox
			// 
			courseComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
			courseComboBox.Enabled = false;
			courseComboBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			courseComboBox.FormattingEnabled = true;
			courseComboBox.Location = new Point(20, 70);
			courseComboBox.Name = "courseComboBox";
			courseComboBox.Size = new Size(700, 36);
			courseComboBox.TabIndex = 5;
			courseComboBox.SelectedIndexChanged += courseComboBox_SelectedIndexChanged;
			// 
			// studentsDataGridView
			// 
			studentsDataGridView.AllowUserToAddRows = false;
			studentsDataGridView.AllowUserToDeleteRows = false;
			studentsDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
			studentsDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			studentsDataGridView.Location = new Point(12, 315);
			studentsDataGridView.Name = "studentsDataGridView";
			studentsDataGridView.RowHeadersWidth = 51;
			studentsDataGridView.Size = new Size(960, 300);
			studentsDataGridView.TabIndex = 6;
			// 
			// updateGradesButton
			// 
			updateGradesButton.Enabled = false;
			updateGradesButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			updateGradesButton.Location = new Point(350, 630);
			updateGradesButton.Name = "updateGradesButton";
			updateGradesButton.Size = new Size(180, 45);
			updateGradesButton.TabIndex = 7;
			updateGradesButton.Text = "&Update Grades";
			updateGradesButton.UseVisualStyleBackColor = true;
			updateGradesButton.Click += updateGradesButton_Click;
			// 
			// closeButton
			// 
			closeButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			closeButton.Location = new Point(550, 630);
			closeButton.Name = "closeButton";
			closeButton.Size = new Size(120, 45);
			closeButton.TabIndex = 8;
			closeButton.Text = "&Close";
			closeButton.UseVisualStyleBackColor = true;
			closeButton.Click += closeButton_Click;
			// 
			// instructorGroupBox
			// 
			instructorGroupBox.Controls.Add(instructorIdLabel);
			instructorGroupBox.Controls.Add(instructorIdTextBox);
			instructorGroupBox.Controls.Add(loadCoursesButton);
			instructorGroupBox.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
			instructorGroupBox.Location = new Point(12, 60);
			instructorGroupBox.Name = "instructorGroupBox";
			instructorGroupBox.Size = new Size(960, 90);
			instructorGroupBox.TabIndex = 9;
			instructorGroupBox.TabStop = false;
			instructorGroupBox.Text = "Step 1: Enter Instructor ID";
			// 
			// courseGroupBox
			// 
			courseGroupBox.Controls.Add(courseLabel);
			courseGroupBox.Controls.Add(courseComboBox);
			courseGroupBox.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
			courseGroupBox.Location = new Point(12, 165);
			courseGroupBox.Name = "courseGroupBox";
			courseGroupBox.Size = new Size(960, 130);
			courseGroupBox.TabIndex = 10;
			courseGroupBox.TabStop = false;
			courseGroupBox.Text = "Step 2: Select Course";
			// 
			// statusStrip
			// 
			statusStrip.ImageScalingSize = new Size(20, 20);
			statusStrip.Items.AddRange(new ToolStripItem[] { statusLabel });
			statusStrip.Location = new Point(0, 688);
			statusStrip.Name = "statusStrip";
			statusStrip.Size = new Size(984, 26);
			statusStrip.TabIndex = 11;
			statusStrip.Text = "statusStrip1";
			// 
			// statusLabel
			// 
			statusLabel.Name = "statusLabel";
			statusLabel.Size = new Size(151, 20);
			statusLabel.Text = "Enter Instructor ID to begin";
			// 
			// AssignGradesForm
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(984, 714);
			Controls.Add(statusStrip);
			Controls.Add(courseGroupBox);
			Controls.Add(instructorGroupBox);
			Controls.Add(closeButton);
			Controls.Add(updateGradesButton);
			Controls.Add(studentsDataGridView);
			Controls.Add(titleLabel);
			Name = "AssignGradesForm";
			Text = "Assign Grades";
			((System.ComponentModel.ISupportInitialize)studentsDataGridView).EndInit();
			instructorGroupBox.ResumeLayout(false);
			instructorGroupBox.PerformLayout();
			courseGroupBox.ResumeLayout(false);
			courseGroupBox.PerformLayout();
			statusStrip.ResumeLayout(false);
			statusStrip.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label titleLabel;
		private Label instructorIdLabel;
		private TextBox instructorIdTextBox;
		private Button loadCoursesButton;
		private Label courseLabel;
		private ComboBox courseComboBox;
		private DataGridView studentsDataGridView;
		private Button updateGradesButton;
		private Button closeButton;
		private GroupBox instructorGroupBox;
		private GroupBox courseGroupBox;
		private StatusStrip statusStrip;
		private ToolStripStatusLabel statusLabel;
	}
}
