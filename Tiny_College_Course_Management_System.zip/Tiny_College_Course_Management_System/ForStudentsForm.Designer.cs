﻿namespace Tiny_College_Course_Management_System
{
	partial class ForStudentsForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			viewMyCoursesButton = new Button();
			viewAvailableCoursesButton = new Button();
			closeButton = new Button();
			forStudentsGroupBox = new GroupBox();
			forStudentsGroupBox.SuspendLayout();
			SuspendLayout();
			// 
			// viewMyCoursesButton
			// 
			viewMyCoursesButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			viewMyCoursesButton.Location = new Point(30, 40);
			viewMyCoursesButton.Name = "viewMyCoursesButton";
			viewMyCoursesButton.Size = new Size(250, 50);
			viewMyCoursesButton.TabIndex = 1;
			viewMyCoursesButton.Text = "View &My Courses";
			viewMyCoursesButton.UseVisualStyleBackColor = true;
			viewMyCoursesButton.Click += viewMyCoursesButton_Click;
			// 
			// viewAvailableCoursesButton
			// 
			viewAvailableCoursesButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			viewAvailableCoursesButton.Location = new Point(30, 110);
			viewAvailableCoursesButton.Name = "viewAvailableCoursesButton";
			viewAvailableCoursesButton.Size = new Size(250, 50);
			viewAvailableCoursesButton.TabIndex = 2;
			viewAvailableCoursesButton.Text = "View &Available Courses";
			viewAvailableCoursesButton.UseVisualStyleBackColor = true;
			viewAvailableCoursesButton.Click += viewAvailableCoursesButton_Click;
			// 
			// closeButton
			// 
			closeButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			closeButton.Location = new Point(81, 227);
			closeButton.Name = "closeButton";
			closeButton.Size = new Size(150, 45);
			closeButton.TabIndex = 3;
			closeButton.Text = "C&lose";
			closeButton.UseVisualStyleBackColor = true;
			closeButton.Click += closeButton_Click;
			// 
			// forStudentsGroupBox
			// 
			forStudentsGroupBox.Controls.Add(viewMyCoursesButton);
			forStudentsGroupBox.Controls.Add(viewAvailableCoursesButton);
			forStudentsGroupBox.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			forStudentsGroupBox.Location = new Point(12, 12);
			forStudentsGroupBox.Name = "forStudentsGroupBox";
			forStudentsGroupBox.Size = new Size(308, 193);
			forStudentsGroupBox.TabIndex = 4;
			forStudentsGroupBox.TabStop = false;
			forStudentsGroupBox.Text = "For Students";
			// 
			// ForStudentsForm
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(338, 298);
			Controls.Add(forStudentsGroupBox);
			Controls.Add(closeButton);
			Name = "ForStudentsForm";
			Text = "For Students";
			forStudentsGroupBox.ResumeLayout(false);
			ResumeLayout(false);
		}

		#endregion
		private Button viewMyCoursesButton;
		private Button viewAvailableCoursesButton;
		private Button closeButton;
		private GroupBox forStudentsGroupBox;
	}
}
