﻿/*
CISS 311 - ADVANCED AGILE SOFTWARE DEVELOPMENT
Instructor: Michael Miracle
 
Team 2: The Agile Minds
Members: Audrey Gamble, Jahmai Hawkins, Sandrin Tebo, Tiny Walters, Jacob Decker, Joe Fague
Course Project 2: Tiny College Course Mgmt database
 
11/25/2025
*/
//This form is for students to view their courses and available courses.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tiny_College_Course_Management_System
{
	public partial class ForStudentsForm : Form
	{
		public ForStudentsForm()
		{
			InitializeComponent();
		}

		private void viewMyCoursesButton_Click(object sender, EventArgs e)//opens form to view courses a student is enrolled in
		{
			WhatCoursesAStudentEnrolledForm whatCoursesAStudentEnrolledForm = new WhatCoursesAStudentEnrolledForm();
			whatCoursesAStudentEnrolledForm.ShowDialog();
		}

		private void viewAvailableCoursesButton_Click(object sender, EventArgs e)//opens form to view all available courses
		{
			AllCoursesForm allCoursesForm = new AllCoursesForm();
			allCoursesForm.ShowDialog();
		}

		private void closeButton_Click(object sender, EventArgs e)
		{
			Close();
		}
	}
}
