﻿/*
CISS 311 - ADVANCED AGILE SOFTWARE DEVELOPMENT
Instructor: Michael Miracle
 
Team 2: The Agile Minds
Members: Audrey Gamble, Jahmai Hawkins, Sandrin Tebo, Tiny Walters, Jacob Decker, Joe Fague
Course Project 2: Tiny College Course Mgmt database
 
11/25/2025
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Tiny_College_Course_Management_System
{
	public partial class WhatCoursesAStudentEnrolledForm : Form
	{
		private int studentId = 0;
		private int currentStudentId = 0;
		private string studentName = "";
		private string currentStudentName = "";
		private int totalCredits=0;
		public WhatCoursesAStudentEnrolledForm()
		{
			InitializeComponent();
		}

		private void studentIdTextBox_TextChanged(object sender, EventArgs e)// Student ID Text Changed
		{
			if (int.TryParse(studentIdTextBox.Text, out int id))// Validate Student ID input
			{
					studentId = id;
					feedbackToolStripStatusLabel.Text = "Ready to search.";// Valid Student ID
			}
			else
				{
					studentId = 0;
					feedbackToolStripStatusLabel.Text = "Enter a Student ID.";// Invalid Student ID
			}
		
		
			using SqlConnection conn = new(Properties.Settings.Default.connString);// Database connection
			conn.Open();// Open the connection
			using SqlCommand cmd = new("SELECT StudentName, Email FROM Students WHERE StudentID = @StudentID", conn);
			// SQL command to get student info
			cmd.Parameters.AddWithValue("@StudentID", studentId);// Add parameter for SQL command

			using SqlDataReader reader = cmd.ExecuteReader();// Execute the command and get the data reader
			currentStudentId = studentId;// Set current student ID to searched ID
			currentStudentName = reader.GetString(0);// Get student name from the first column
			string email = reader.GetString(1);// Get student email from the next column

			 // Display student info
			feedbackToolStripStatusLabel.Text = $"Student Found:\nName: {currentStudentName}\nEmail: {email}";
			// Load student's courses
			reader.Close();// Close the reader
			LoadStudentCourses(studentId);// Load courses method for showing courses
		}
				
		private void LoadStudentCourses(int studentId)// Load Student Courses Method
		{
			using SqlConnection conn = new(Properties.Settings.Default.connString);// Database connection
			conn.Open();// Open the connection

			// Load all courses (with and without grades)
			using SqlCommand cmd = new(@"SELECT c.CourseID, c.Title AS CourseTitle, i.InstructorName, c.CreditHours,
					CASE 
						WHEN r.Grade IS NULL 
						THEN 'In Progress' 
						ELSE r.Grade 
					END AS Grade
					FROM Registrations r INNER JOIN Courses c ON r.CourseID = c.CourseID
						INNER JOIN Instructors i ON c.InstructorID = i.InstructorID
					WHERE r.StudentID = @StudentID
					ORDER BY c.Title", conn);// SQL command to get courses for the student

			cmd.Parameters.AddWithValue("@StudentID", studentId);// Add parameter for SQL command
			DataTable dt = new DataTable();// DataTable to hold course data
			using SqlDataAdapter adapter = new SqlDataAdapter(cmd);// Data adapter to fill the DataTable
			adapter.Fill(dt);// Fill the DataTable with course data
			coursesDataGridView.DataSource = dt;// Set DataGridView data source to the DataTable

			// Format column headers
			coursesDataGridView.Columns["CourseID"].HeaderText = "Course ID";
			coursesDataGridView.Columns["CourseID"].Width = 80;
			coursesDataGridView.Columns["CourseTitle"].HeaderText = "Course Title";
			coursesDataGridView.Columns["InstructorName"].HeaderText = "Instructor";
			coursesDataGridView.Columns["CreditHours"].HeaderText = "Credits";
			coursesDataGridView.Columns["CreditHours"].Width = 80;
			coursesDataGridView.Columns["Grade"].HeaderText = "Grade";
			coursesDataGridView.Columns["Grade"].Width = 80;
				

			// Calculate total completed credit hours (grades A, B, or C)
			CalculateCompletedCredits(studentId);
			}

		private void CalculateCompletedCredits(int studentId)
		{
			using SqlConnection conn = new(Properties.Settings.Default.connString);
			conn.Open();
			// Calculate total credit hours for courses with grades A, B, or C
			using SqlCommand cmd = new(@"SELECT SUM(c.CreditHours) AS TotalCredits
					FROM Registrations r INNER JOIN Courses c ON r.CourseID = c.CourseID
					WHERE r.StudentID = @StudentID
					AND r.Grade IN ('A', 'B', 'C')", conn);

			cmd.Parameters.AddWithValue("@StudentID", studentId);
			totalCreditsValueLabel.Text = totalCredits.ToString();

			// Check for graduation eligibility (120+ credits with C or better)
			if (totalCredits >= 120)
			{
				statusLabel.Text = $"{currentStudentName} is eligible for graduation! ({totalCredits} credits)";

				// Show congratulations popup
				MessageBox.Show($"Congratulations, {currentStudentName}!\n\n You have graduated from Tiny College!");

			} 
		}
		private void closeButton_Click(object sender, EventArgs e)
		{
			Close();
		}
	}
}
