﻿namespace Tiny_College_Course_Management_System
{
	partial class ForInstructorsForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			viewAllCoursesButton = new Button();
			viewStudentsInCourseButton = new Button();
			assignGradesButton = new Button();
			closeButton = new Button();
			instructorGroupBox = new GroupBox();
			instructorGroupBox.SuspendLayout();
			SuspendLayout();
			// 
			// viewAllCoursesButton
			// 
			viewAllCoursesButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			viewAllCoursesButton.Location = new Point(30, 40);
			viewAllCoursesButton.Name = "viewAllCoursesButton";
			viewAllCoursesButton.Size = new Size(250, 50);
			viewAllCoursesButton.TabIndex = 1;
			viewAllCoursesButton.Text = "View All &Courses";
			viewAllCoursesButton.UseVisualStyleBackColor = true;
			viewAllCoursesButton.Click += viewAllCoursesButton_Click;
			// 
			// viewStudentsInCourseButton
			// 
			viewStudentsInCourseButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			viewStudentsInCourseButton.Location = new Point(30, 110);
			viewStudentsInCourseButton.Name = "viewStudentsInCourseButton";
			viewStudentsInCourseButton.Size = new Size(250, 50);
			viewStudentsInCourseButton.TabIndex = 2;
			viewStudentsInCourseButton.Text = "View &Students in Course";
			viewStudentsInCourseButton.UseVisualStyleBackColor = true;
			viewStudentsInCourseButton.Click += viewStudentsInCourseButton_Click;
			// 
			// assignGradesButton
			// 
			assignGradesButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			assignGradesButton.Location = new Point(30, 180);
			assignGradesButton.Name = "assignGradesButton";
			assignGradesButton.Size = new Size(250, 50);
			assignGradesButton.TabIndex = 3;
			assignGradesButton.Text = "Assign &Grades";
			assignGradesButton.UseVisualStyleBackColor = true;
			assignGradesButton.Click += assignGradesButton_Click;
			// 
			// closeButton
			// 
			closeButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			closeButton.Location = new Point(82, 302);
			closeButton.Name = "closeButton";
			closeButton.Size = new Size(150, 45);
			closeButton.TabIndex = 4;
			closeButton.Text = "C&lose";
			closeButton.UseVisualStyleBackColor = true;
			closeButton.Click += closeButton_Click;
			// 
			// instructorGroupBox
			// 
			instructorGroupBox.Controls.Add(viewAllCoursesButton);
			instructorGroupBox.Controls.Add(viewStudentsInCourseButton);
			instructorGroupBox.Controls.Add(assignGradesButton);
			instructorGroupBox.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
			instructorGroupBox.Location = new Point(12, 12);
			instructorGroupBox.Name = "instructorGroupBox";
			instructorGroupBox.Size = new Size(297, 256);
			instructorGroupBox.TabIndex = 5;
			instructorGroupBox.TabStop = false;
			instructorGroupBox.Text = "Instructor Functions";
			// 
			// ForInstructorsForm
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(347, 381);
			Controls.Add(instructorGroupBox);
			Controls.Add(closeButton);
			Name = "ForInstructorsForm";
			Text = "Instructor Dashboard";
			instructorGroupBox.ResumeLayout(false);
			ResumeLayout(false);
		}

		#endregion
		private Button viewAllCoursesButton;
		private Button viewStudentsInCourseButton;
		private Button assignGradesButton;
		private Button closeButton;
		private GroupBox instructorGroupBox;
	}
}
