﻿namespace Tiny_College_Course_Management_System
{
	partial class ForAdministratorsForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			addInstructorButton = new Button();
			addStudentButton = new Button();
			addCourseButton = new Button();
			viewAllStudentsButton = new Button();
			viewAllCoursesButton = new Button();
			enrollStudentButton = new Button();
			closeButton = new Button();
			forAdministratorsGroupBox = new GroupBox();
			forAdministratorsGroupBox.SuspendLayout();
			SuspendLayout();
			// 
			// addInstructorButton
			// 
			addInstructorButton.Font = new Font("Segoe UI", 12F);
			addInstructorButton.Location = new Point(34, 35);
			addInstructorButton.Name = "addInstructorButton";
			addInstructorButton.Size = new Size(250, 50);
			addInstructorButton.TabIndex = 0;
			addInstructorButton.Text = "Add &Instructor";
			addInstructorButton.UseVisualStyleBackColor = true;
			addInstructorButton.Click += addInstructorButton_Click;
			// 
			// addStudentButton
			// 
			addStudentButton.Font = new Font("Segoe UI", 12F);
			addStudentButton.Location = new Point(34, 100);
			addStudentButton.Name = "addStudentButton";
			addStudentButton.Size = new Size(250, 50);
			addStudentButton.TabIndex = 1;
			addStudentButton.Text = "Add &Student";
			addStudentButton.UseVisualStyleBackColor = true;
			addStudentButton.Click += addStudentButton_Click;
			// 
			// addCourseButton
			// 
			addCourseButton.Font = new Font("Segoe UI", 12F);
			addCourseButton.Location = new Point(34, 165);
			addCourseButton.Name = "addCourseButton";
			addCourseButton.Size = new Size(250, 50);
			addCourseButton.TabIndex = 2;
			addCourseButton.Text = "Add &Course";
			addCourseButton.UseVisualStyleBackColor = true;
			addCourseButton.Click += addCourseButton_Click;
			// 
			// viewAllStudentsButton
			// 
			viewAllStudentsButton.Font = new Font("Segoe UI", 12F);
			viewAllStudentsButton.Location = new Point(34, 230);
			viewAllStudentsButton.Name = "viewAllStudentsButton";
			viewAllStudentsButton.Size = new Size(250, 50);
			viewAllStudentsButton.TabIndex = 3;
			viewAllStudentsButton.Text = "&View All Students";
			viewAllStudentsButton.UseVisualStyleBackColor = true;
			viewAllStudentsButton.Click += viewAllStudentsButton_Click;
			// 
			// viewAllCoursesButton
			// 
			viewAllCoursesButton.Font = new Font("Segoe UI", 12F);
			viewAllCoursesButton.Location = new Point(34, 295);
			viewAllCoursesButton.Name = "viewAllCoursesButton";
			viewAllCoursesButton.Size = new Size(250, 50);
			viewAllCoursesButton.TabIndex = 4;
			viewAllCoursesButton.Text = "View All C&ourses";
			viewAllCoursesButton.UseVisualStyleBackColor = true;
			viewAllCoursesButton.Click += viewAllCoursesButton_Click;
			// 
			// enrollStudentButton
			// 
			enrollStudentButton.Font = new Font("Segoe UI", 12F);
			enrollStudentButton.Location = new Point(34, 360);
			enrollStudentButton.Name = "enrollStudentButton";
			enrollStudentButton.Size = new Size(250, 50);
			enrollStudentButton.TabIndex = 5;
			enrollStudentButton.Text = "&Enroll Student in Course";
			enrollStudentButton.UseVisualStyleBackColor = true;
			enrollStudentButton.Click += enrollStudentButton_Click;
			// 
			// closeButton
			// 
			closeButton.Font = new Font("Segoe UI", 12F);
			closeButton.Location = new Point(92, 481);
			closeButton.Name = "closeButton";
			closeButton.Size = new Size(150, 45);
			closeButton.TabIndex = 6;
			closeButton.Text = "C&lose";
			closeButton.UseVisualStyleBackColor = true;
			closeButton.Click += closeButton_Click;
			// 
			// forAdministratorsGroupBox
			// 
			forAdministratorsGroupBox.Controls.Add(addInstructorButton);
			forAdministratorsGroupBox.Controls.Add(addStudentButton);
			forAdministratorsGroupBox.Controls.Add(addCourseButton);
			forAdministratorsGroupBox.Controls.Add(viewAllStudentsButton);
			forAdministratorsGroupBox.Controls.Add(viewAllCoursesButton);
			forAdministratorsGroupBox.Controls.Add(enrollStudentButton);
			forAdministratorsGroupBox.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
			forAdministratorsGroupBox.Location = new Point(12, 12);
			forAdministratorsGroupBox.Name = "forAdministratorsGroupBox";
			forAdministratorsGroupBox.Size = new Size(314, 445);
			forAdministratorsGroupBox.TabIndex = 7;
			forAdministratorsGroupBox.TabStop = false;
			forAdministratorsGroupBox.Text = "Administrator Functions";
			// 
			// ForAdministratorsForm
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(359, 542);
			Controls.Add(forAdministratorsGroupBox);
			Controls.Add(closeButton);
			Name = "ForAdministratorsForm";
			Text = "Administrator Dashboard";
			forAdministratorsGroupBox.ResumeLayout(false);
			ResumeLayout(false);
		}

		#endregion

		private Button addInstructorButton;
		private Button addStudentButton;
		private Button addCourseButton;
		private Button viewAllStudentsButton;
		private Button viewAllCoursesButton;
		private Button enrollStudentButton;
		private Button closeButton;
		private GroupBox forAdministratorsGroupBox;
	}
}
