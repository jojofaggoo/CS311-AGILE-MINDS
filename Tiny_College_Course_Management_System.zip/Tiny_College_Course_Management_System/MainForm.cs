﻿/*
CISS 311 - ADVANCED AGILE SOFTWARE DEVELOPMENT
Instructor: Michael Miracle
 
Team 2: The Agile Minds
Members: Audrey Gamble, Jahmai Hawkins, Sandrin Tebo, Tiny Walters, Jacob Decker, Joe Fague
Course Project 2: Tiny College Course Mgmt database
 
11/25/2025
*/
//This is the main form for the Tiny College Course Management System application.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tiny_College_Course_Management_System
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}

		private void forStudentsButton_Click(object sender, EventArgs e)//opens the For Students form
		{
			ForStudentsForm forStudentsForm = new ForStudentsForm();
			forStudentsForm.ShowDialog();
		}

		private void forInstructorsButton_Click(object sender, EventArgs e)//opens the For Instructors form
		{
			ForInstructorsForm forInstructorsForm = new ForInstructorsForm();
			forInstructorsForm.ShowDialog();
		}

		private void forAdministratorsButton_Click(object sender, EventArgs e)//opens the For Administrators form
		{
			ForAdministratorsForm forAdministratorsForm = new ForAdministratorsForm();
			forAdministratorsForm.ShowDialog();
		}

		private void button1_Click(object sender, EventArgs e)//opens the Project one Course Tracking System form
		{
			CourseTrackingSystemForm courseTrackingSystemForm = new CourseTrackingSystemForm();
			courseTrackingSystemForm.ShowDialog();
		}

		private void exitButton_Click(object sender, EventArgs e)
		{
			Close();
		}
	}
}
