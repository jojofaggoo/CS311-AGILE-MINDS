﻿/*
CISS 311 - ADVANCED AGILE SOFTWARE DEVELOPMENT
Instructor: Michael Miracle
 
Team 2: The Agile Minds
Members: Audrey Gamble, Jahmai Hawkins, Sandrin Tebo, Tiny Walters, Jacob Decker, Joe Fague
Course Project 2: Tiny College Course Mgmt database
 
11/25/2025
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tiny_College_Course_Management_System
{
	internal class CourseComboBoxItem//helper class to represent course details in the courseComboBox
	{
		public string CourseID { get; set; }//Property to hold the unique identifier for the course
		public string Title { get; set; }//Property to hold the title of the course
		public string InstructorName { get; set; }//Property to hold the name of the instructor for the course
		public int AvailableSeats { get; set; }//Property to hold the number of available seats in the course
		public int MaxSeats { get; set; }//Property to hold the maximum number of seats in the course
		public int CreditHours { get; set; }//Property to hold the credit hours for the course

		public override string ToString()//Overrides the ToString method to provide details about the course
		{
			string str;
			str = ($"{Title} - {InstructorName} ({AvailableSeats} seats available)");//Formats the string to include title, instructor name, and available seats
			return str;
		}
	}
}
