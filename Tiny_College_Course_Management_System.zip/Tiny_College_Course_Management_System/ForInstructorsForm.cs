﻿/*
CISS 311 - ADVANCED AGILE SOFTWARE DEVELOPMENT
Instructor: Michael Miracle
 
Team 2: The Agile Minds
Members: Audrey Gamble, Jahmai Hawkins, Sandrin Tebo, Tiny Walters, Jacob Decker, Joe Fague
Course Project 2: Tiny College Course Mgmt database
 
11/25/2025
*/
//This form is for instructors to view courses and students in their courses.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tiny_College_Course_Management_System
{
	public partial class ForInstructorsForm : Form
	{
		public ForInstructorsForm()
		{
			InitializeComponent();
		}

		private void viewAllCoursesButton_Click(object sender, EventArgs e)//opens AllCoursesForm
		{
			AllCoursesForm allCoursesForm = new AllCoursesForm();
			allCoursesForm.ShowDialog();
		}

		private void viewStudentsInCourseButton_Click(object sender, EventArgs e)//opens WhoIsInACourseForm
		{
			WhoIsInACourseForm whoIsInACourseForm = new WhoIsInACourseForm();
			whoIsInACourseForm.ShowDialog();
		}

		private void assignGradesButton_Click(object sender, EventArgs e)//opens AssignGradesForm
		{
			AssignGradesForm assignGradesForm = new AssignGradesForm();
			assignGradesForm.ShowDialog();
		}

		private void closeButton_Click(object sender, EventArgs e)
		{
			Close();
		}
	}
}
