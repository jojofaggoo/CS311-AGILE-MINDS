﻿namespace Tiny_College_Course_Management_System
{
	partial class AddACourseForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			closeButton = new Button();
			addCourseButton = new Button();
			enterCourseDataGroupBox = new GroupBox();
			isActiveCheckBox = new CheckBox();
			creditHoursTextBox = new TextBox();
			creditHoursLabel = new Label();
			availableSeatsTextBox = new TextBox();
			availableSeatsLabel = new Label();
			maxSeatsTextBox = new TextBox();
			maxSeatsLabel = new Label();
			instructorIDTextBox = new TextBox();
			instructorIDLabel = new Label();
			courseTitleTextBox = new TextBox();
			courseTitleLabel = new Label();
			feedbackToolStripStatusLabel = new StatusStrip();
			enterCourseDataGroupBox.SuspendLayout();
			SuspendLayout();
			// 
			// closeButton
			// 
			closeButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
			closeButton.BackColor = SystemColors.ScrollBar;
			closeButton.Font = new Font("Segoe Fluent Icons", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
			closeButton.Location = new Point(265, 329);
			closeButton.Margin = new Padding(0);
			closeButton.Name = "closeButton";
			closeButton.Size = new Size(141, 47);
			closeButton.TabIndex = 10;
			closeButton.Text = "Cl&ose";
			closeButton.TextAlign = ContentAlignment.TopCenter;
			closeButton.UseVisualStyleBackColor = false;
			closeButton.Click += closeButton_Click;
			// 
			// addCourseButton
			// 
			addCourseButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
			addCourseButton.BackColor = SystemColors.ScrollBar;
			addCourseButton.Font = new Font("Segoe Fluent Icons", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
			addCourseButton.Location = new Point(66, 329);
			addCourseButton.Margin = new Padding(0);
			addCourseButton.Name = "addCourseButton";
			addCourseButton.Size = new Size(161, 47);
			addCourseButton.TabIndex = 9;
			addCourseButton.Text = "&Add  Course";
			addCourseButton.TextAlign = ContentAlignment.TopCenter;
			addCourseButton.UseVisualStyleBackColor = false;
			addCourseButton.Click += addCourseButton_Click;
			// 
			// enterCourseDataGroupBox
			// 
			enterCourseDataGroupBox.Controls.Add(isActiveCheckBox);
			enterCourseDataGroupBox.Controls.Add(creditHoursTextBox);
			enterCourseDataGroupBox.Controls.Add(creditHoursLabel);
			enterCourseDataGroupBox.Controls.Add(availableSeatsTextBox);
			enterCourseDataGroupBox.Controls.Add(availableSeatsLabel);
			enterCourseDataGroupBox.Controls.Add(maxSeatsTextBox);
			enterCourseDataGroupBox.Controls.Add(maxSeatsLabel);
			enterCourseDataGroupBox.Controls.Add(instructorIDTextBox);
			enterCourseDataGroupBox.Controls.Add(instructorIDLabel);
			enterCourseDataGroupBox.Controls.Add(courseTitleTextBox);
			enterCourseDataGroupBox.Controls.Add(courseTitleLabel);
			enterCourseDataGroupBox.Location = new Point(12, 11);
			enterCourseDataGroupBox.Name = "enterCourseDataGroupBox";
			enterCourseDataGroupBox.Size = new Size(483, 300);
			enterCourseDataGroupBox.TabIndex = 8;
			enterCourseDataGroupBox.TabStop = false;
			enterCourseDataGroupBox.Text = "Enter Course Data";
			// 
			// isActiveCheckBox
			// 
			isActiveCheckBox.AutoSize = true;
			isActiveCheckBox.Font = new Font("Segoe UI", 10.2F);
			isActiveCheckBox.Location = new Point(16, 251);
			isActiveCheckBox.Name = "isActiveCheckBox";
			isActiveCheckBox.Size = new Size(200, 27);
			isActiveCheckBox.TabIndex = 16;
			isActiveCheckBox.Text = "Active for Registration";
			isActiveCheckBox.UseVisualStyleBackColor = true;
			// 
			// creditHoursTextBox
			// 
			creditHoursTextBox.Font = new Font("Segoe UI", 10.2F);
			creditHoursTextBox.Location = new Point(221, 207);
			creditHoursTextBox.Name = "creditHoursTextBox";
			creditHoursTextBox.Size = new Size(210, 30);
			creditHoursTextBox.TabIndex = 15;
			// 
			// creditHoursLabel
			// 
			creditHoursLabel.Font = new Font("Segoe UI", 10.2F);
			creditHoursLabel.Location = new Point(16, 202);
			creditHoursLabel.Name = "creditHoursLabel";
			creditHoursLabel.Size = new Size(154, 35);
			creditHoursLabel.TabIndex = 14;
			creditHoursLabel.Text = "Credit Hours:";
			// 
			// availableSeatsTextBox
			// 
			availableSeatsTextBox.Font = new Font("Segoe UI", 10.2F);
			availableSeatsTextBox.Location = new Point(221, 166);
			availableSeatsTextBox.Name = "availableSeatsTextBox";
			availableSeatsTextBox.Size = new Size(210, 30);
			availableSeatsTextBox.TabIndex = 13;
			// 
			// availableSeatsLabel
			// 
			availableSeatsLabel.Font = new Font("Segoe UI", 10.2F);
			availableSeatsLabel.Location = new Point(16, 161);
			availableSeatsLabel.Name = "availableSeatsLabel";
			availableSeatsLabel.Size = new Size(199, 35);
			availableSeatsLabel.TabIndex = 12;
			availableSeatsLabel.Text = "Available Seats:";
			// 
			// maxSeatsTextBox
			// 
			maxSeatsTextBox.Font = new Font("Segoe UI", 10.2F);
			maxSeatsTextBox.Location = new Point(221, 125);
			maxSeatsTextBox.Name = "maxSeatsTextBox";
			maxSeatsTextBox.Size = new Size(210, 30);
			maxSeatsTextBox.TabIndex = 11;
			// 
			// maxSeatsLabel
			// 
			maxSeatsLabel.Font = new Font("Segoe UI", 10.2F);
			maxSeatsLabel.Location = new Point(16, 120);
			maxSeatsLabel.Name = "maxSeatsLabel";
			maxSeatsLabel.Size = new Size(154, 35);
			maxSeatsLabel.TabIndex = 10;
			maxSeatsLabel.Text = "Max Seats:";
			// 
			// instructorIDTextBox
			// 
			instructorIDTextBox.Font = new Font("Segoe UI", 10.2F);
			instructorIDTextBox.Location = new Point(221, 83);
			instructorIDTextBox.Name = "instructorIDTextBox";
			instructorIDTextBox.Size = new Size(210, 30);
			instructorIDTextBox.TabIndex = 5;
			// 
			// instructorIDLabel
			// 
			instructorIDLabel.Font = new Font("Segoe UI", 10.2F);
			instructorIDLabel.Location = new Point(16, 78);
			instructorIDLabel.Name = "instructorIDLabel";
			instructorIDLabel.Size = new Size(154, 35);
			instructorIDLabel.TabIndex = 4;
			instructorIDLabel.Text = "Instructor ID:";
			// 
			// courseTitleTextBox
			// 
			courseTitleTextBox.Font = new Font("Segoe UI", 10.2F);
			courseTitleTextBox.Location = new Point(176, 38);
			courseTitleTextBox.Name = "courseTitleTextBox";
			courseTitleTextBox.Size = new Size(255, 30);
			courseTitleTextBox.TabIndex = 3;
			// 
			// courseTitleLabel
			// 
			courseTitleLabel.Font = new Font("Segoe UI", 10.2F);
			courseTitleLabel.Location = new Point(16, 33);
			courseTitleLabel.Name = "courseTitleLabel";
			courseTitleLabel.Size = new Size(154, 35);
			courseTitleLabel.TabIndex = 2;
			courseTitleLabel.Text = "Course Title:";
			// 
			// feedbackToolStripStatusLabel
			// 
			feedbackToolStripStatusLabel.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			feedbackToolStripStatusLabel.ImageScalingSize = new Size(20, 20);
			feedbackToolStripStatusLabel.Location = new Point(0, 388);
			feedbackToolStripStatusLabel.Name = "feedbackToolStripStatusLabel";
			feedbackToolStripStatusLabel.Size = new Size(516, 22);
			feedbackToolStripStatusLabel.TabIndex = 7;
			feedbackToolStripStatusLabel.Text = "statusStrip1";
			// 
			// AddACourseForm
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(516, 410);
			Controls.Add(closeButton);
			Controls.Add(addCourseButton);
			Controls.Add(enterCourseDataGroupBox);
			Controls.Add(feedbackToolStripStatusLabel);
			Name = "AddACourseForm";
			Text = "Add a Course";
			enterCourseDataGroupBox.ResumeLayout(false);
			enterCourseDataGroupBox.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Button closeButton;
		private Button addCourseButton;
		private GroupBox enterCourseDataGroupBox;
		private TextBox courseTitleTextBox;
		private Label courseTitleLabel;
		private StatusStrip feedbackToolStripStatusLabel;
		private TextBox instructorIDTextBox;
		private Label instructorIDLabel;
		private TextBox maxSeatsTextBox;
		private Label maxSeatsLabel;
		private TextBox availableSeatsTextBox;
		private Label availableSeatsLabel;
		private TextBox creditHoursTextBox;
		private Label creditHoursLabel;
		private CheckBox isActiveCheckBox;
	}
}