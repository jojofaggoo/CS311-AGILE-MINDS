﻿namespace Tiny_College_Course_Management_System
{
	partial class AddAStudentForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			feedbackToolStripStatusLabel = new StatusStrip();
			enterStudentDataGroupBox = new GroupBox();
			label1 = new Label();
			newStudentEmailTextBox = new TextBox();
			newStudentNameTextBox = new TextBox();
			newStudentNameLabel = new Label();
			addStudentButton = new Button();
			closeButton = new Button();
			enterStudentDataGroupBox.SuspendLayout();
			SuspendLayout();
			// 
			// feedbackToolStripStatusLabel
			// 
			feedbackToolStripStatusLabel.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			feedbackToolStripStatusLabel.ImageScalingSize = new Size(20, 20);
			feedbackToolStripStatusLabel.Location = new Point(0, 255);
			feedbackToolStripStatusLabel.Name = "feedbackToolStripStatusLabel";
			feedbackToolStripStatusLabel.Size = new Size(511, 22);
			feedbackToolStripStatusLabel.TabIndex = 0;
			feedbackToolStripStatusLabel.Text = "statusStrip1";
			// 
			// enterStudentDataGroupBox
			// 
			enterStudentDataGroupBox.Controls.Add(label1);
			enterStudentDataGroupBox.Controls.Add(newStudentEmailTextBox);
			enterStudentDataGroupBox.Controls.Add(newStudentNameTextBox);
			enterStudentDataGroupBox.Controls.Add(newStudentNameLabel);
			enterStudentDataGroupBox.Location = new Point(12, 21);
			enterStudentDataGroupBox.Name = "enterStudentDataGroupBox";
			enterStudentDataGroupBox.Size = new Size(483, 156);
			enterStudentDataGroupBox.TabIndex = 1;
			enterStudentDataGroupBox.TabStop = false;
			enterStudentDataGroupBox.Text = "Enter New Student Data";
			// 
			// label1
			// 
			label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label1.Location = new Point(56, 91);
			label1.Name = "label1";
			label1.Size = new Size(142, 41);
			label1.TabIndex = 5;
			label1.Text = "Student Email:";
			// 
			// newStudentEmailTextBox
			// 
			newStudentEmailTextBox.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
			newStudentEmailTextBox.Location = new Point(204, 91);
			newStudentEmailTextBox.Name = "newStudentEmailTextBox";
			newStudentEmailTextBox.Size = new Size(255, 38);
			newStudentEmailTextBox.TabIndex = 4;
			// 
			// newStudentNameTextBox
			// 
			newStudentNameTextBox.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
			newStudentNameTextBox.Location = new Point(204, 39);
			newStudentNameTextBox.Name = "newStudentNameTextBox";
			newStudentNameTextBox.Size = new Size(255, 38);
			newStudentNameTextBox.TabIndex = 3;
			// 
			// newStudentNameLabel
			// 
			newStudentNameLabel.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			newStudentNameLabel.Location = new Point(56, 44);
			newStudentNameLabel.Name = "newStudentNameLabel";
			newStudentNameLabel.Size = new Size(142, 49);
			newStudentNameLabel.TabIndex = 2;
			newStudentNameLabel.Text = "Student Name:";
			// 
			// addStudentButton
			// 
			addStudentButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
			addStudentButton.BackColor = SystemColors.ScrollBar;
			addStudentButton.Font = new Font("Segoe Fluent Icons", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
			addStudentButton.Location = new Point(106, 192);
			addStudentButton.Margin = new Padding(0);
			addStudentButton.Name = "addStudentButton";
			addStudentButton.Size = new Size(161, 47);
			addStudentButton.TabIndex = 5;
			addStudentButton.Text = "&Add  Student";
			addStudentButton.TextAlign = ContentAlignment.TopCenter;
			addStudentButton.UseVisualStyleBackColor = false;
			addStudentButton.Click += addStudentButton_Click;
			// 
			// closeButton
			// 
			closeButton.AutoSizeMode = AutoSizeMode.GrowAndShrink;
			closeButton.BackColor = SystemColors.ScrollBar;
			closeButton.Font = new Font("Segoe Fluent Icons", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
			closeButton.Location = new Point(305, 192);
			closeButton.Margin = new Padding(0);
			closeButton.Name = "closeButton";
			closeButton.Size = new Size(141, 47);
			closeButton.TabIndex = 6;
			closeButton.Text = "Cl&ose";
			closeButton.TextAlign = ContentAlignment.TopCenter;
			closeButton.UseVisualStyleBackColor = false;
			closeButton.Click += closeButton_Click;
			// 
			// AddAStudentForm
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(511, 277);
			Controls.Add(closeButton);
			Controls.Add(addStudentButton);
			Controls.Add(enterStudentDataGroupBox);
			Controls.Add(feedbackToolStripStatusLabel);
			Name = "AddAStudentForm";
			Text = "Add A Student";
			enterStudentDataGroupBox.ResumeLayout(false);
			enterStudentDataGroupBox.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private StatusStrip feedbackToolStripStatusLabel;
		private GroupBox enterStudentDataGroupBox;
		private Label newStudentNameLabel;
		private TextBox newStudentNameTextBox;
		private Button addStudentButton;
		private Button closeButton;
		private Label label1;
		private TextBox newStudentEmailTextBox;
	}
}