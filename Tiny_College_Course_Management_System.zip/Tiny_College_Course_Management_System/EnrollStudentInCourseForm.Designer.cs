﻿namespace Tiny_College_Course_Management_System
{
	partial class EnrollStudentInCourseForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			titleLabel = new Label();
			studentIdLabel = new Label();
			studentIdTextBox = new TextBox();
			studentInfoLabel = new Label();
			courseSearchLabel = new Label();
			courseSearchTextBox = new TextBox();
			searchButton = new Button();
			coursesDataGridView = new DataGridView();
			enrollButton = new Button();
			closeButton = new Button();
			studentGroupBox = new GroupBox();
			courseGroupBox = new GroupBox();
			feedbackToolStripStatusLabel = new StatusStrip();
			statusLabel = new ToolStripStatusLabel();
			((System.ComponentModel.ISupportInitialize)coursesDataGridView).BeginInit();
			studentGroupBox.SuspendLayout();
			courseGroupBox.SuspendLayout();
			feedbackToolStripStatusLabel.SuspendLayout();
			SuspendLayout();
			// 
			// titleLabel
			// 
			titleLabel.AutoSize = true;
			titleLabel.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
			titleLabel.Location = new Point(12, 9);
			titleLabel.Name = "titleLabel";
			titleLabel.Size = new Size(358, 41);
			titleLabel.TabIndex = 0;
			titleLabel.Text = "Enroll Student in Course";
			// 
			// studentIdLabel
			// 
			studentIdLabel.AutoSize = true;
			studentIdLabel.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			studentIdLabel.Location = new Point(20, 35);
			studentIdLabel.Name = "studentIdLabel";
			studentIdLabel.Size = new Size(108, 28);
			studentIdLabel.TabIndex = 1;
			studentIdLabel.Text = "Student ID:";
			// 
			// studentIdTextBox
			// 
			studentIdTextBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			studentIdTextBox.Location = new Point(132, 32);
			studentIdTextBox.Name = "studentIdTextBox";
			studentIdTextBox.Size = new Size(150, 34);
			studentIdTextBox.TabIndex = 2;
			studentIdTextBox.TextChanged += studentIdTextBox_TextChanged;
			// 
			// studentInfoLabel
			// 
			studentInfoLabel.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
			studentInfoLabel.ForeColor = SystemColors.ControlText;
			studentInfoLabel.Location = new Point(305, 18);
			studentInfoLabel.Name = "studentInfoLabel";
			studentInfoLabel.Size = new Size(415, 117);
			studentInfoLabel.TabIndex = 3;
			studentInfoLabel.Text = "Enter a student ID to begin";
			// 
			// courseSearchLabel
			// 
			courseSearchLabel.AutoSize = true;
			courseSearchLabel.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			courseSearchLabel.Location = new Point(20, 35);
			courseSearchLabel.Name = "courseSearchLabel";
			courseSearchLabel.Size = new Size(208, 28);
			courseSearchLabel.TabIndex = 4;
			courseSearchLabel.Text = "Search Course by Title:";
			// 
			// courseSearchTextBox
			// 
			courseSearchTextBox.Enabled = false;
			courseSearchTextBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			courseSearchTextBox.Location = new Point(20, 70);
			courseSearchTextBox.Name = "courseSearchTextBox";
			courseSearchTextBox.PlaceholderText = "Enter course title (partial match allowed)";
			courseSearchTextBox.Size = new Size(500, 34);
			courseSearchTextBox.TabIndex = 5;
			// 
			// searchButton
			// 
			searchButton.Enabled = false;
			searchButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			searchButton.Location = new Point(540, 66);
			searchButton.Name = "searchButton";
			searchButton.Size = new Size(120, 42);
			searchButton.TabIndex = 6;
			searchButton.Text = "&Search";
			searchButton.UseVisualStyleBackColor = true;
			searchButton.Click += searchButton_Click;
			// 
			// coursesDataGridView
			// 
			coursesDataGridView.AllowUserToAddRows = false;
			coursesDataGridView.AllowUserToDeleteRows = false;
			coursesDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
			coursesDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			coursesDataGridView.Location = new Point(20, 120);
			coursesDataGridView.MultiSelect = false;
			coursesDataGridView.Name = "coursesDataGridView";
			coursesDataGridView.ReadOnly = true;
			coursesDataGridView.RowHeadersWidth = 51;
			coursesDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
			coursesDataGridView.Size = new Size(700, 250);
			coursesDataGridView.TabIndex = 7;
			// 
			// enrollButton
			// 
			enrollButton.Enabled = false;
			enrollButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			enrollButton.Location = new Point(280, 625);
			enrollButton.Name = "enrollButton";
			enrollButton.Size = new Size(150, 45);
			enrollButton.TabIndex = 8;
			enrollButton.Text = "&Enroll";
			enrollButton.UseVisualStyleBackColor = true;
			enrollButton.Click += enrollButton_Click;
			// 
			// closeButton
			// 
			closeButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			closeButton.Location = new Point(450, 625);
			closeButton.Name = "closeButton";
			closeButton.Size = new Size(120, 45);
			closeButton.TabIndex = 9;
			closeButton.Text = "&Close";
			closeButton.UseVisualStyleBackColor = true;
			closeButton.Click += closeButton_Click;
			// 
			// studentGroupBox
			// 
			studentGroupBox.Controls.Add(studentIdLabel);
			studentGroupBox.Controls.Add(studentIdTextBox);
			studentGroupBox.Controls.Add(studentInfoLabel);
			studentGroupBox.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
			studentGroupBox.Location = new Point(12, 60);
			studentGroupBox.Name = "studentGroupBox";
			studentGroupBox.Size = new Size(760, 155);
			studentGroupBox.TabIndex = 10;
			studentGroupBox.TabStop = false;
			studentGroupBox.Text = "Step 1: Enter Student ID";
			// 
			// courseGroupBox
			// 
			courseGroupBox.Controls.Add(courseSearchLabel);
			courseGroupBox.Controls.Add(courseSearchTextBox);
			courseGroupBox.Controls.Add(searchButton);
			courseGroupBox.Controls.Add(coursesDataGridView);
			courseGroupBox.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
			courseGroupBox.Location = new Point(12, 225);
			courseGroupBox.Name = "courseGroupBox";
			courseGroupBox.Size = new Size(760, 390);
			courseGroupBox.TabIndex = 11;
			courseGroupBox.TabStop = false;
			courseGroupBox.Text = "Step 2: Search and Select Course";
			// 
			// feedbackToolStripStatusLabel
			// 
			feedbackToolStripStatusLabel.ImageScalingSize = new Size(20, 20);
			feedbackToolStripStatusLabel.Items.AddRange(new ToolStripItem[] { statusLabel });
			feedbackToolStripStatusLabel.Location = new Point(0, 684);
			feedbackToolStripStatusLabel.Name = "feedbackToolStripStatusLabel";
			feedbackToolStripStatusLabel.Size = new Size(784, 26);
			feedbackToolStripStatusLabel.TabIndex = 12;
			feedbackToolStripStatusLabel.Text = "feedbackToolStripStatusLabel";
			// 
			// statusLabel
			// 
			statusLabel.Name = "statusLabel";
			statusLabel.Size = new Size(177, 20);
			statusLabel.Text = "Enter Student ID to begin";
			// 
			// EnrollStudentInCourseForm
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(784, 710);
			Controls.Add(feedbackToolStripStatusLabel);
			Controls.Add(courseGroupBox);
			Controls.Add(studentGroupBox);
			Controls.Add(closeButton);
			Controls.Add(enrollButton);
			Controls.Add(titleLabel);
			Name = "EnrollStudentInCourseForm";
			Text = "Enroll Student in Course";
			((System.ComponentModel.ISupportInitialize)coursesDataGridView).EndInit();
			studentGroupBox.ResumeLayout(false);
			studentGroupBox.PerformLayout();
			courseGroupBox.ResumeLayout(false);
			courseGroupBox.PerformLayout();
			feedbackToolStripStatusLabel.ResumeLayout(false);
			feedbackToolStripStatusLabel.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label titleLabel;
		private Label studentIdLabel;
		private TextBox studentIdTextBox;
		private Label studentInfoLabel;
		private Label courseSearchLabel;
		private TextBox courseSearchTextBox;
		private Button searchButton;
		private DataGridView coursesDataGridView;
		private Button enrollButton;
		private Button closeButton;
		private GroupBox studentGroupBox;
		private GroupBox courseGroupBox;
		private StatusStrip feedbackToolStripStatusLabel;
		private ToolStripStatusLabel statusLabel;
	}
}
