﻿namespace Tiny_College_Course_Management_System
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			label1 = new Label();
			forAdministratorsButton = new Button();
			forInstructorsButton = new Button();
			forStudentsButton = new Button();
			button1 = new Button();
			exitButton = new Button();
			SuspendLayout();
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Font = new Font("Segoe Script", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label1.Location = new Point(7, 40);
			label1.Name = "label1";
			label1.Size = new Size(516, 36);
			label1.TabIndex = 0;
			label1.Text = "Tiny College Course Management System";
			// 
			// forAdministratorsButton
			// 
			forAdministratorsButton.Font = new Font("PT Sans", 10.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
			forAdministratorsButton.Location = new Point(136, 179);
			forAdministratorsButton.Name = "forAdministratorsButton";
			forAdministratorsButton.Size = new Size(258, 37);
			forAdministratorsButton.TabIndex = 1;
			forAdministratorsButton.Text = "For Administrators";
			forAdministratorsButton.UseVisualStyleBackColor = true;
			forAdministratorsButton.Click += forAdministratorsButton_Click;
			// 
			// forInstructorsButton
			// 
			forInstructorsButton.Font = new Font("PT Sans", 10.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
			forInstructorsButton.Location = new Point(136, 249);
			forInstructorsButton.Name = "forInstructorsButton";
			forInstructorsButton.Size = new Size(258, 37);
			forInstructorsButton.TabIndex = 2;
			forInstructorsButton.Text = "For Instructors";
			forInstructorsButton.UseVisualStyleBackColor = true;
			forInstructorsButton.Click += forInstructorsButton_Click;
			// 
			// forStudentsButton
			// 
			forStudentsButton.Font = new Font("PT Sans", 10.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
			forStudentsButton.Location = new Point(136, 319);
			forStudentsButton.Name = "forStudentsButton";
			forStudentsButton.Size = new Size(258, 37);
			forStudentsButton.TabIndex = 3;
			forStudentsButton.Text = "For Students";
			forStudentsButton.UseVisualStyleBackColor = true;
			forStudentsButton.Click += forStudentsButton_Click;
			// 
			// button1
			// 
			button1.Font = new Font("Segoe Print", 10.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
			button1.Location = new Point(72, 109);
			button1.Name = "button1";
			button1.Size = new Size(386, 37);
			button1.TabIndex = 4;
			button1.Text = "Tiny College Course Tracking System";
			button1.UseVisualStyleBackColor = true;
			button1.Click += button1_Click;
			// 
			// exitButton
			// 
			exitButton.Font = new Font("PT Sans", 10.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
			exitButton.Location = new Point(136, 384);
			exitButton.Name = "exitButton";
			exitButton.Size = new Size(258, 37);
			exitButton.TabIndex = 5;
			exitButton.Text = "E&xit";
			exitButton.UseVisualStyleBackColor = true;
			exitButton.Click += exitButton_Click;
			// 
			// MainForm
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(548, 433);
			Controls.Add(exitButton);
			Controls.Add(button1);
			Controls.Add(forStudentsButton);
			Controls.Add(forInstructorsButton);
			Controls.Add(forAdministratorsButton);
			Controls.Add(label1);
			Name = "MainForm";
			Text = "Welcome";
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label label1;
		private Button forAdministratorsButton;
		private Button forInstructorsButton;
		private Button forStudentsButton;
		private Button button1;
		private Button exitButton;
	}
}