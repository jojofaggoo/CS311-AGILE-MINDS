﻿/*
CISS 311 - ADVANCED AGILE SOFTWARE DEVELOPMENT
Instructor: Michael Miracle
 
Team 2: The Agile Minds
Members: Audrey Gamble, Jahmai Hawkins, Sandrin Tebo, Tiny Walters, Jacob Decker, Joe Fague
Course Project 2: Tiny College Course Mgmt database
 
11/25/2025
*/
//This form displays all courses in a data grid view and can be edited.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Tiny_College_Course_Management_System
{
	public partial class AllCoursesForm : Form
	{
		public AllCoursesForm()
		{
			InitializeComponent();
		}

		private void AllCoursesForm_Load(object sender, EventArgs e)// When the form loads, load the courses into the data grid view
		{
			LoadCourses();
		}

		private void LoadCourses()//This method loads all courses from the database into the data grid view
		{
			using SqlConnection conn = new(Properties.Settings.Default.connString);// Create a connection to the database
			using SqlCommand cmd = new(@"SELECT c.CourseID,	c.Title,i.InstructorName,c.MaxSeats,c.AvailableSeats,c.CreditHours,
				CASE WHEN c.IsActive = 1 
						THEN 'Yes' 
						ELSE 'No' 
				END AS Active
				FROM Courses c INNER JOIN Instructors i ON c.InstructorID = i.InstructorID
				ORDER BY c.Title", conn);// Create a command to select all courses with instructor names
			conn.Open();// Open the connection
			SqlDataAdapter adapter = new SqlDataAdapter(cmd);// Create a data adapter to fill a data table
			DataTable dt = new DataTable();// Create a data table to hold the data
			adapter.Fill(dt);// Fill the data table with the data from the database
			coursesDataGridView.DataSource = dt;// Set the data source of the data grid view to the data table

			// Formatted column headers for the data grid view
			coursesDataGridView.Columns["CourseID"].HeaderText = "Course ID";
			coursesDataGridView.Columns["Title"].HeaderText = "Course Title";
			coursesDataGridView.Columns["InstructorName"].HeaderText = "Instructor";
			coursesDataGridView.Columns["MaxSeats"].HeaderText = "Max Seats";
			coursesDataGridView.Columns["AvailableSeats"].HeaderText = "Available Seats";
			coursesDataGridView.Columns["CreditHours"].HeaderText = "Credit Hours";
			coursesDataGridView.Columns["Active"].HeaderText = "Active for Registration";
		}

		private void closeButton_Click(object sender, EventArgs e)
		{
			Close();
		}
	}
}
