/*
CISS 311 - ADVANCED AGILE SOFTWARE DEVELOPMENT
Instructor: Michael Miracle
 
Team 2: The Agile Minds
Members: Audrey Gamble, Jahmai Hawkins, Sandrin Tebo, Tiny Walters, Jacob Decker, Joe Fague
Course Project 2: Tiny College Course Mgmt database
 
11/25/2025
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tiny_College_Course_Management_System
{
	public partial class AddInstructorForm : Form
	{
		public AddInstructorForm()
		{
			InitializeComponent();
		}

		private void addInstructorButton_Click(object sender, EventArgs e)
		{
				using SqlConnection conn = new(Properties.Settings.Default.connString);
				conn.Open();

				// Insert the new instructor
				using SqlCommand cmd = new("INSERT INTO Instructors(InstructorName, Email) VALUES (@InstructorName, @Email)", conn);
				cmd.Parameters.AddWithValue("@InstructorName", newInstructorNameTextBox.Text);
				cmd.Parameters.AddWithValue("@Email", newInstructorEmailTextBox.Text);
				cmd.ExecuteNonQuery();
				feedbackToolStripStatusLabel.Text = "Instructor added successfully.";
			
				// Clear the form for next entry
				newInstructorNameTextBox.Clear();
				newInstructorEmailTextBox.Clear();
				newInstructorNameTextBox.Focus();
		}

		private void closeButton_Click(object sender, EventArgs e)
		{
			Close();
		}
	}
}
