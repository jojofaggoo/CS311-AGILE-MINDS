﻿/*
CISS 311 - ADVANCED AGILE SOFTWARE DEVELOPMENT
Instructor: Michael Miracle
 
Team 2: The Agile Minds
Members: Audrey Gamble, Jahmai Hawkins, Sandrin Tebo, Tiny Walters, Jacob Decker, Joe Fague
Course Project 2: Tiny College Course Mgmt database
 
11/25/2025
*/
//This form displays the list of students enrolled in a selected course.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Tiny_College_Course_Management_System
{
public partial class WhoIsInACourseForm : Form
{
	public WhoIsInACourseForm()
	{
		InitializeComponent();
	}

	private void WhoIsInACourseForm_Load(object sender, EventArgs e)
	{
		LoadCourses();
	}

	private void LoadCourses()
	{
			using SqlConnection conn = new(Properties.Settings.Default.connString);// Set up the connection using the connection string from settings
		using SqlCommand cmd = new(@"SELECT c.CourseID,	c.Title, i.InstructorName
				FROM Courses c INNER JOIN Instructors i ON c.InstructorID = i.InstructorID
				ORDER BY c.Title", conn);// SQL query to get course details along with instructor names
		conn.Open();// Open the database connection
		SqlDataReader reader = cmd.ExecuteReader();// Execute the query and get a data reader
		courseComboBox.Items.Clear();
			while (reader.Read())
			{
				courseComboBox.Items.Add(new ComboBoxItem
				{
					Value = reader["CourseID"].ToString(),
					Text = $"{reader["Title"]} - {reader["InstructorName"]}"
				});
			}
			courseComboBox.SelectedIndex = 0;
		}

	private void courseComboBox_SelectedIndexChanged(object sender, EventArgs e)// Event handler for when the selected course changes
	{
		if (courseComboBox.SelectedIndex > 0 && courseComboBox.SelectedItem is ComboBoxItem course)// Check if a valid course is selected
		{
			LoadCourseStudents(course.Value);// Load students for the selected course
		}
		else
		{
			studentsDataGridView.DataSource = null;// Clear the data grid view if no valid course is selected
		}
	}

	private void LoadCourseStudents(string courseID)
	{
		using SqlConnection conn = new(Properties.Settings.Default.connString);
			using SqlCommand cmd = new(@"SELECT s.StudentID,s.StudentName,s.Email,
				CASE WHEN r.Grade IS NULL THEN 'In Progress' 
				ELSE r.Grade END AS Grade
				FROM Registrations r INNER JOIN Students s ON r.StudentID = s.StudentID
				WHERE r.CourseID = @courseID
				ORDER BY s.StudentName", conn);// SQL query to get students enrolled in the selected course

		cmd.Parameters.AddWithValue("@courseID", courseID);// Add the courseID parameter to the SQL command
		conn.Open();// Open the database connection
		SqlDataAdapter adapter = new SqlDataAdapter(cmd);// Create a data adapter to fill the data table
		DataTable dt = new DataTable();// Create a data table to hold the results
		adapter.Fill(dt);// Fill the data table with the results from the query
		studentsDataGridView.DataSource = dt;// Bind the data table to the data grid view

		// Format column headers
		if (studentsDataGridView.Columns.Count > 0)
			{
				studentsDataGridView.Columns["StudentID"].HeaderText = "Student ID";
				studentsDataGridView.Columns["StudentName"].HeaderText = "Student Name";
				studentsDataGridView.Columns["Email"].HeaderText = "Email";
				studentsDataGridView.Columns["Grade"].HeaderText = "Grade";
			}

			if (dt.Rows.Count == 0)
			{
				MessageBox.Show("No students are enrolled in this course.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
		}
	private void closeButton_Click(object sender, EventArgs e)
	{
		Close();
	}
}
}
