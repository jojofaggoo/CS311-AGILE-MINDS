﻿/*
CISS 311 - ADVANCED AGILE SOFTWARE DEVELOPMENT
Instructor: Michael Miracle
 
Team 2: The Agile Minds
Members: Audrey Gamble, Jahmai Hawkins, Sandrin Tebo, Tiny Walters, Jacob Decker, Joe Fague
Course Project 2: Tiny College Course Mgmt database
 
11/25/2025
*/
//This form displays all students in the Tiny College Course Management System.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Tiny_College_Course_Management_System
{
	public partial class AllStudentsForm : Form
	{
		public AllStudentsForm()
		{
			InitializeComponent();
		}
		private void AllStudentsForm_Load(object sender, EventArgs e)
		{
			LoadStudents();
		}
		private void LoadStudents()//Method to load and display all students from the database
		{
			using SqlConnection conn = new(Properties.Settings.Default.connString);//Establish database connection
			using SqlCommand cmd = new("SELECT StudentID, StudentName, Email FROM Students ORDER BY StudentName", conn);//Execute command and fill DataTable
			conn.Open();//Open connection
			SqlDataAdapter adapter = new SqlDataAdapter(cmd);//Data adapter to fill DataTable
			DataTable dt = new DataTable();//DataTable to hold student data
			adapter.Fill(dt);//Fill DataTable with data from database
			studentsDataGridView.DataSource = dt;//Bind DataTable to DataGridView
			// Format column headers
			studentsDataGridView.Columns["StudentID"].HeaderText = "Student ID";
			studentsDataGridView.Columns["StudentName"].HeaderText = "Student Name";
			studentsDataGridView.Columns["Email"].HeaderText = "Email";
		}
		private void closeButton_Click(object sender, EventArgs e)
		{
			Close();
		}
	}
}
