﻿/*
CISS 311 - ADVANCED AGILE SOFTWARE DEVELOPMENT
Instructor: Michael Miracle
 
Team 2: The Agile Minds
Members: Audrey Gamble, Jahmai Hawkins, Sandrin Tebo, Tiny Walters, Jacob Decker, Joe Fague
Course Project 2: Tiny College Course Mgmt database
 
11/25/2025
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tiny_College_Course_Management_System
{
	public partial class ForAdministratorsForm : Form
	{
		public ForAdministratorsForm()
		{
			InitializeComponent();
		}

		private void addInstructorButton_Click(object sender, EventArgs e)//opens AddInstructorForm
		{
			AddInstructorForm addInstructorForm = new AddInstructorForm();
			addInstructorForm.ShowDialog();
		}

		private void addStudentButton_Click(object sender, EventArgs e)//opens AddAStudentForm
		{
			AddAStudentForm addAStudentForm = new AddAStudentForm();
			addAStudentForm.ShowDialog();
		}

		private void addCourseButton_Click(object sender, EventArgs e)//opens AddACourseForm
		{
			AddACourseForm addACourseForm = new AddACourseForm();
			addACourseForm.ShowDialog();
		}

		private void viewAllStudentsButton_Click(object sender, EventArgs e)//opens AllStudentsForm
		{
			AllStudentsForm allStudentsForm = new AllStudentsForm();
			allStudentsForm.ShowDialog();
		}

		private void viewAllCoursesButton_Click(object sender, EventArgs e)//opens AllCoursesForm
		{
			AllCoursesForm allCoursesForm = new AllCoursesForm();
			allCoursesForm.ShowDialog();
		}

		private void enrollStudentButton_Click(object sender, EventArgs e)//opens EnrollStudentInCourseForm
		{
			EnrollStudentInCourseForm enrollStudentInCourseForm = new EnrollStudentInCourseForm();
			enrollStudentInCourseForm.ShowDialog();
		}

		private void closeButton_Click(object sender, EventArgs e)
		{
			Close();
		}
	}
}
