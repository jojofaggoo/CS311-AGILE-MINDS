/*
CISS 311 - ADVANCED AGILE SOFTWARE DEVELOPMENT
Instructor: Michael Miracle
 
Team 2: The Agile Minds
Members: Audrey Gamble, Jahmai Hawkins, Sandrin Tebo, Tiny Walters, Jacob Decker, Joe Fague
Course Project 2: Tiny College Course Mgmt database
 
11/25/2025
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tiny_College_Course_Management_System
{
	public partial class AssignGradesForm : Form
	{
		private int currentInstructorId = 0;

		public AssignGradesForm()
		{
			InitializeComponent();
		}

		private void loadCoursesButton_Click(object sender, EventArgs e)
		{
			// Validate instructor ID
			if (string.IsNullOrWhiteSpace(instructorIdTextBox.Text))
			{
				MessageBox.Show("Please enter an Instructor ID.", "Validation Error", 
					MessageBoxButtons.OK, MessageBoxIcon.Warning);
				instructorIdTextBox.Focus();
				return;
			}

			if (!int.TryParse(instructorIdTextBox.Text, out int instructorId) || instructorId <= 0)
			{
				MessageBox.Show("Please enter a valid Instructor ID (positive number).", "Validation Error", 
					MessageBoxButtons.OK, MessageBoxIcon.Warning);
				instructorIdTextBox.Focus();
				return;
			}

			try
			{
				using SqlConnection conn = new(Properties.Settings.Default.connString);
				conn.Open();

				// First, verify the instructor exists
				using SqlCommand checkCmd = new("SELECT COUNT(*) FROM Instructors WHERE InstructorID = @InstructorID", conn);
				checkCmd.Parameters.AddWithValue("@InstructorID", instructorId);
				int count = (int)checkCmd.ExecuteScalar();

				if (count == 0)
				{
					MessageBox.Show($"Instructor ID {instructorId} not found in the system.", "Invalid Instructor", 
						MessageBoxButtons.OK, MessageBoxIcon.Error);
					instructorIdTextBox.Focus();
					return;
				}

				// Load courses taught by this instructor
				using SqlCommand cmd = new(@"
					SELECT CourseID, Title, MaxSeats, AvailableSeats, CreditHours
					FROM Courses
					WHERE InstructorID = @InstructorID
					ORDER BY Title", conn);
				cmd.Parameters.AddWithValue("@InstructorID", instructorId);

				courseComboBox.Items.Clear();
				using SqlDataReader reader = cmd.ExecuteReader();
				
				bool hasCourses = false;
				while (reader.Read())
				{
					hasCourses = true;
					CourseItem item = new CourseItem
					{
						CourseID = reader.GetInt32(0),
						Title = reader.GetString(1),
						MaxSeats = reader.GetInt32(2),
						AvailableSeats = reader.GetInt32(3),
						CreditHours = reader.GetInt32(4)
					};
					courseComboBox.Items.Add(item);
				}

				if (hasCourses)
				{
					currentInstructorId = instructorId;
					courseComboBox.Enabled = true;
					statusLabel.Text = $"Courses loaded for Instructor ID {instructorId}. Select a course.";
					MessageBox.Show($"Courses loaded successfully for Instructor ID {instructorId}.", "Success", 
						MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
				else
				{
					MessageBox.Show($"Instructor ID {instructorId} has no courses assigned.", "No Courses", 
						MessageBoxButtons.OK, MessageBoxIcon.Information);
					courseComboBox.Enabled = false;
					statusLabel.Text = "No courses found for this instructor.";
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Error loading courses: {ex.Message}", "Database Error", 
					MessageBoxButtons.OK, MessageBoxIcon.Error);
				statusLabel.Text = "Error loading courses.";
			}
		}

		private void courseComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (courseComboBox.SelectedItem == null) return;

			CourseItem selectedCourse = (CourseItem)courseComboBox.SelectedItem;
			LoadStudentsForCourse(selectedCourse.CourseID);
		}

		private void LoadStudentsForCourse(int courseId)
		{
			try
			{
				using SqlConnection conn = new(Properties.Settings.Default.connString);
				conn.Open();

				using SqlCommand cmd = new(@"
					SELECT 
						r.StudentID,
						s.StudentName,
						s.Email,
						r.Grade
					FROM Registrations r
					INNER JOIN Students s ON r.StudentID = s.StudentID
					WHERE r.CourseID = @CourseID
					ORDER BY s.StudentName", conn);
				cmd.Parameters.AddWithValue("@CourseID", courseId);

				DataTable dt = new DataTable();
				using SqlDataAdapter adapter = new SqlDataAdapter(cmd);
				adapter.Fill(dt);

				if (dt.Rows.Count > 0)
				{
					studentsDataGridView.DataSource = dt;
					
					// Make only the Grade column editable
					foreach (DataGridViewColumn column in studentsDataGridView.Columns)
					{
						if (column.Name == "Grade")
						{
							column.ReadOnly = false;
							column.Width = 80;
						}
						else
						{
							column.ReadOnly = true;
						}
					}

					// Format column headers
					studentsDataGridView.Columns["StudentID"].HeaderText = "Student ID";
					studentsDataGridView.Columns["StudentName"].HeaderText = "Student Name";
					studentsDataGridView.Columns["Email"].HeaderText = "Email";
					studentsDataGridView.Columns["Grade"].HeaderText = "Grade";

					updateGradesButton.Enabled = true;
					statusLabel.Text = $"Loaded {dt.Rows.Count} student(s). Edit grades and click Update.";
				}
				else
				{
					studentsDataGridView.DataSource = null;
					updateGradesButton.Enabled = false;
					statusLabel.Text = "No students enrolled in this course.";
					MessageBox.Show("No students are enrolled in this course.", "No Enrollments", 
						MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Error loading students: {ex.Message}", "Database Error", 
					MessageBoxButtons.OK, MessageBoxIcon.Error);
				statusLabel.Text = "Error loading students.";
			}
		}

		private void updateGradesButton_Click(object sender, EventArgs e)
		{
			if (courseComboBox.SelectedItem == null)
			{
				MessageBox.Show("Please select a course first.", "Validation Error", 
					MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			CourseItem selectedCourse = (CourseItem)courseComboBox.SelectedItem;
			int updatedCount = 0;
			int errorCount = 0;
			List<string> errors = new List<string>();

			try
			{
				using SqlConnection conn = new(Properties.Settings.Default.connString);
				conn.Open();

				// Process each row in the DataGridView
				foreach (DataGridViewRow row in studentsDataGridView.Rows)
				{
					if (row.IsNewRow) continue;

					int studentId = Convert.ToInt32(row.Cells["StudentID"].Value);
					object gradeValue = row.Cells["Grade"].Value;

					// Convert DBNull to null
					string grade = (gradeValue == null || gradeValue == DBNull.Value) ? null : gradeValue.ToString()?.Trim().ToUpper();

					// Validate grade if not null
					if (!string.IsNullOrEmpty(grade))
					{
						if (grade.Length != 1 || !"ABCDF".Contains(grade))
						{
							errors.Add($"Student ID {studentId}: Invalid grade '{grade}'. Must be A, B, C, D, or F.");
							errorCount++;
							continue;
						}
					}

					// Update the grade
					using SqlCommand cmd = new(@"
						UPDATE Registrations 
						SET Grade = @Grade 
						WHERE StudentID = @StudentID AND CourseID = @CourseID", conn);
					
					if (string.IsNullOrEmpty(grade))
						cmd.Parameters.AddWithValue("@Grade", DBNull.Value);
					else
						cmd.Parameters.AddWithValue("@Grade", grade);
					
					cmd.Parameters.AddWithValue("@StudentID", studentId);
					cmd.Parameters.AddWithValue("@CourseID", selectedCourse.CourseID);

					int rowsAffected = cmd.ExecuteNonQuery();
					if (rowsAffected > 0)
						updatedCount++;
				}

				// Show results
				string message = $"Grades updated successfully!\n\nUpdated: {updatedCount} student(s)";
				if (errorCount > 0)
				{
					message += $"\nErrors: {errorCount} student(s)\n\nError Details:\n" + string.Join("\n", errors);
					MessageBox.Show(message, "Update Complete with Errors", 
						MessageBoxButtons.OK, MessageBoxIcon.Warning);
				}
				else
				{
					MessageBox.Show(message, "Success", 
						MessageBoxButtons.OK, MessageBoxIcon.Information);
				}

				statusLabel.Text = $"Updated {updatedCount} grade(s).";

				// Reload the data to show updated grades
				LoadStudentsForCourse(selectedCourse.CourseID);
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Error updating grades: {ex.Message}", "Database Error", 
					MessageBoxButtons.OK, MessageBoxIcon.Error);
				statusLabel.Text = "Error updating grades.";
			}
		}

		private void closeButton_Click(object sender, EventArgs e)
		{
			Close();
		}

		// Helper class for course items
		private class CourseItem
		{
			public int CourseID { get; set; }
			public string Title { get; set; }
			public int MaxSeats { get; set; }
			public int AvailableSeats { get; set; }
			public int CreditHours { get; set; }

			public override string ToString()
			{
				return $"{CourseID} - {Title} ({MaxSeats - AvailableSeats}/{MaxSeats} enrolled, {CreditHours} credits)";
			}
		}
	}
}
